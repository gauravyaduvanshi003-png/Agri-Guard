import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

const app = express();
const PORT = Number(process.env.PORT || 3001);

app.use(cors());
app.use(express.json({ limit: '15mb' }));

const DIAGNOSIS_SCHEMA_PROMPT = `You are Agri Guard's senior plant pathologist and agronomist.
Analyze the provided image carefully and return ONLY valid JSON matching this exact structure:
{
  "isLeaf": boolean,
  "rejectionReason": string | null,
  "plantCommonName": string,
  "plantScientificName": string,
  "diseaseName": string,
  "isHealthy": boolean,
  "pathogenType": "Fungal" | "Bacterial" | "Viral" | "Oomycete" | "Pest / Mite" | "Nutrient / Abiotic" | "Healthy" | "Non-Plant",
  "severity": "None" | "Low" | "Moderate" | "High" | "Critical",
  "confidence": number,
  "summary": string,
  "observedSymptoms": string[],
  "howToSolve": {
    "immediateActions": string[],
    "organicRemedies": string[],
    "targetedTreatments": string[],
    "recoveryTimeline": string
  },
  "healthyCareAdvice": {
    "watering": string,
    "sunlightAndAirflow": string,
    "soilAndNutrition": string,
    "preventiveChecklist": string[]
  },
  "accuracyNotes": string
}

Rules:
1. First verify whether the image clearly shows a plant leaf or foliage. If it does NOT (e.g., a person, object, blank wall, unreadable blur), set "isLeaf": false, "pathogenType": "Non-Plant", "confidence": 0, and explain clearly in "rejectionReason".
2. Distinguish carefully between fungal/bacterial spots, viral mosaic/curl, nutrient deficiencies, and insect/mite leaf galls or blisters (e.g., raised bumpy galls on hackberry, maple, witch hazel, or oak).
3. Be scientifically honest with "confidence" (0-100). Never blindly report 100% if symptoms overlap, lighting is poor, or multiple diseases look similar. Mention look-alike differentials in "accuracyNotes" if confidence < 92.
4. Give practical, safe, actionable home-garden and farm-ready guidance in "howToSolve" and "healthyCareAdvice" with clear dosages/intervals where appropriate and PPE/label safety reminders for chemical treatments.`;

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'Agri Guard API',
    serverGeminiConfigured: Boolean(process.env.GEMINI_API_KEY?.trim()),
    defaultModel: process.env.GEMINI_MODEL || 'auto',
  });
});

function scoreGeminiModel(modelName) {
  const name = modelName.replace(/^models\//, '').toLowerCase();
  if (!name.startsWith('gemini')) return -1;
  if (
    name.includes('embedding') ||
    name.includes('tts') ||
    name.includes('image') ||
    name.includes('robotics') ||
    name.includes('aqa') ||
    name.includes('lyria')
  ) {
    return -1;
  }

  let score = 10;
  if (name.includes('flash')) score += 40;
  if (name.includes('pro')) score += 25;
  if (name.includes('3.')) score += 35;
  else if (name.includes('2.5')) score += 30;
  else if (name.includes('2.0')) score += 20;
  else if (name.includes('1.5')) score += 10;
  if (name.includes('lite')) score -= 8;
  if (name.includes('exp') || name.includes('thinking')) score -= 5;
  return score;
}

async function listAvailableGeminiModels(apiKey) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey)}`;
  const resp = await fetch(url);
  if (!resp.ok) return [];
  const json = await resp.json();
  const models = Array.isArray(json?.models) ? json.models : [];
  return models
    .filter(
      (m) =>
        Array.isArray(m.supportedGenerationMethods) &&
        m.supportedGenerationMethods.includes('generateContent')
    )
    .map((m) => m.name.replace(/^models\//, ''))
    .filter((name) => scoreGeminiModel(name) > 0)
    .sort((a, b) => scoreGeminiModel(b) - scoreGeminiModel(a));
}

async function generateWithGeminiModel(apiKey, modelName, requestBody) {
  const cleanModel = modelName.replace(/^models\//, '');
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(cleanModel)}:generateContent?key=${encodeURIComponent(apiKey)}`;
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(requestBody),
  });
  return { response, cleanModel };
}

app.post('/api/analyze', async (req, res) => {
  try {
    const {
      imageBase64,
      mimeType = 'image/jpeg',
      plantHint = '',
      symptomsHint = [],
      pixelMetrics = null,
      clientApiKey = '',
      model = process.env.GEMINI_MODEL || 'auto',
    } = req.body || {};

    if (!imageBase64 || typeof imageBase64 !== 'string') {
      return res.status(400).json({ error: 'Missing imageBase64 payload.' });
    }

    const apiKey = (clientApiKey || process.env.GEMINI_API_KEY || '').trim();
    if (!apiKey) {
      return res.status(503).json({
        error: 'No Gemini API key configured on server or client.',
        code: 'NO_API_KEY',
      });
    }

    const cleanBase64 = imageBase64.includes(',')
      ? imageBase64.split(',')[1]
      : imageBase64;

    const contextLines = [];
    if (plantHint && plantHint !== 'auto') {
      contextLines.push(`User-reported plant species/crop: ${plantHint}`);
    }
    if (Array.isArray(symptomsHint) && symptomsHint.length > 0) {
      contextLines.push(`User-noted visual clues: ${symptomsHint.join(', ')}`);
    }
    if (pixelMetrics) {
      contextLines.push(
        `Pre-scan optical telemetry: green=${pixelMetrics.healthyGreenPct}%, chlorosis=${pixelMetrics.chlorosisPct}%, necrosis=${pixelMetrics.necrosisPct}%, rust=${pixelMetrics.rustOrangePct}%, powdery=${pixelMetrics.powderyWhitePct}%, sharpness=${pixelMetrics.sharpnessScore}/100.`
      );
    }

    const promptText = [
      DIAGNOSIS_SCHEMA_PROMPT,
      contextLines.length ? `\nAdditional context:\n${contextLines.join('\n')}` : '',
    ].join('\n');

    const requestBody = {
      contents: [
        {
          role: 'user',
          parts: [
            { text: promptText },
            {
              inlineData: {
                mimeType,
                data: cleanBase64,
              },
            },
          ],
        },
      ],
      generationConfig: {
        temperature: 0.15,
        responseMimeType: 'application/json',
      },
    };

    const fallbackOrder = [
      'gemini-2.5-flash',
      'gemini-2.0-flash',
      'gemini-2.5-pro',
      'gemini-1.5-flash',
    ];

    const candidates = [];
    if (model && model !== 'auto') {
      candidates.push(model);
    }

    let finalResponse = null;
    let usedModel = model;
    let lastErrorBody = '';

    // First try requested model if specified
    for (const candidate of candidates) {
      const attempt = await generateWithGeminiModel(apiKey, candidate, requestBody);
      if (attempt.response.ok) {
        finalResponse = attempt.response;
        usedModel = attempt.cleanModel;
        break;
      }
      lastErrorBody = await attempt.response.text();
      // Only fall back automatically if model was not found / unsupported (404)
      if (attempt.response.status !== 404) {
        return res.status(attempt.response.status).json({
          error: `Gemini API request failed (${attempt.response.status})`,
          details: lastErrorBody.slice(0, 500),
        });
      }
    }

    // If 'auto' or requested model returned 404, query user's live model list + standard fallbacks
    if (!finalResponse) {
      const liveModels = await listAvailableGeminiModels(apiKey);
      const retryList = [...new Set([...liveModels, ...fallbackOrder])].filter(
        (m) => !candidates.includes(m)
      );

      for (const candidate of retryList.slice(0, 5)) {
        const attempt = await generateWithGeminiModel(apiKey, candidate, requestBody);
        if (attempt.response.ok) {
          finalResponse = attempt.response;
          usedModel = attempt.cleanModel;
          break;
        }
        lastErrorBody = await attempt.response.text();
        if (attempt.response.status === 401 || attempt.response.status === 403) {
          return res.status(attempt.response.status).json({
            error: `Gemini API authentication failed (${attempt.response.status})`,
            details: lastErrorBody.slice(0, 500),
          });
        }
      }
    }

    if (!finalResponse) {
      return res.status(404).json({
        error: 'No compatible Gemini vision model responded for this API key (404).',
        details: lastErrorBody.slice(0, 500),
      });
    }

    const data = await finalResponse.json();
    const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!rawText) {
      return res.status(502).json({
        error: 'Vision model returned an empty response.',
      });
    }

    const cleanedJson = rawText
      .trim()
      .replace(/^```json\s*/i, '')
      .replace(/^```\s*/i, '')
      .replace(/\s*```$/i, '');

    const parsed = JSON.parse(cleanedJson);
    return res.json({
      engine: 'gemini-vision',
      model: usedModel,
      diagnosis: parsed,
    });
  } catch (err) {
    console.error('Analyze error:', err);
    return res.status(500).json({
      error: err?.message || 'Unexpected error during analysis.',
    });
  }
});

// Serve built production frontend whenever dist/index.html exists
const distPath = path.join(rootDir, 'dist');
if (process.env.NODE_ENV === 'production' || fs.existsSync(path.join(distPath, 'index.html'))) {
  app.use(express.static(distPath));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

app.listen(PORT, () => {
  console.log(`Agri Guard API server running on http://localhost:${PORT}`);
});
