export const PLANT_SPECIES_OPTIONS = [
  { value: 'auto', label: 'Auto-Detect Plant Leaf' },
  { value: 'Tomato', label: 'Tomato (Solanum lycopersicum)' },
  { value: 'Potato', label: 'Potato (Solanum tuberosum)' },
  { value: 'Apple', label: 'Apple (Malus domestica)' },
  { value: 'Corn', label: 'Corn / Maize (Zea mays)' },
  { value: 'Grape', label: 'Grapevine (Vitis vinifera)' },
  { value: 'Bell Pepper', label: 'Bell Pepper / Chili (Capsicum annuum)' },
  { value: 'Rose', label: 'Rose (Rosa spp.)' },
  { value: 'Citrus', label: 'Citrus / Lemon (Citrus spp.)' },
  { value: 'Strawberry', label: 'Strawberry (Fragaria × ananassa)' },
  { value: 'Rice', label: 'Rice (Oryza sativa)' },
  { value: 'Mango', label: 'Mango (Mangifera indica)' },
  { value: 'Houseplant', label: 'Indoor / Ornamental Foliage' },
];

export const SYMPTOM_CHIPS = [
  { id: 'concentric_rings', label: 'Target / concentric dark rings' },
  { id: 'white_powder', label: 'White powdery coating' },
  { id: 'orange_pustules', label: 'Orange / rust-colored bumps' },
  { id: 'yellow_halo', label: 'Brown spots with yellow halos' },
  { id: 'water_soaked', label: 'Dark water-soaked patches' },
  { id: 'leaf_curl', label: 'Curling, puckering, or mosaic mottling' },
  { id: 'edge_scorch', label: 'Crispy brown edges or burnt tips' },
  { id: 'raised_galls', label: 'Raised bumps, blisters, or leaf galls' },
  { id: 'uniform_yellow', label: 'Overall yellowing (chlorosis)' },
  { id: 'healthy_green', label: 'Deep uniform green, no spots' },
];

export const DISEASE_DATABASE = [
  {
    id: 'tomato-early-blight',
    plantCommonName: 'Tomato',
    plantScientificName: 'Solanum lycopersicum',
    diseaseName: 'Early Blight (Alternaria solani)',
    isHealthy: false,
    pathogenType: 'Fungal',
    severity: 'Moderate',
    summary:
      'A widespread fungal disease producing dark brown concentric "bullseye" lesions surrounded by yellow chlorotic halos, usually starting on older lower leaves.',
    observedSymptoms: [
      'Dark brown circular spots with target-like concentric rings',
      'Yellow halo expanding around necrotic lesions',
      'Lower, older leaves affected first before moving upward',
    ],
    signature: {
      necrosisMin: 6,
      chlorosisMin: 8,
      idealGreen: [25, 72],
      idealChlorosis: [8, 38],
      idealNecrosis: [6, 35],
      idealRust: [0, 8],
      idealPowdery: [0, 6],
      idealEdgeBrown: [2, 20],
      symptomTags: ['concentric_rings', 'yellow_halo'],
    },
    howToSolve: {
      immediateActions: [
        'Prune and bag all heavily spotted lower leaves immediately; do not compost infected foliage.',
        'Sterilize pruning shears with 70% isopropyl alcohol or 10% diluted bleach between plants.',
        'Apply a clean layer of straw or dry mulch beneath the plant to stop soil spores from splashing onto leaves.',
      ],
      organicRemedies: [
        'Spray liquid copper fungicide or Bacillus subtilis bio-fungicide every 7–10 days starting at first symptoms.',
        'Use cold-pressed neem oil (5 ml/L water + a few drops of mild liquid soap) in the early evening to slow spore germination.',
      ],
      targetedTreatments: [
        'For severe spread in humid conditions, alternate protectant fungicides (chlorothalonil or mancozeb) per label intervals.',
        'Ensure thorough coverage on both upper and lower leaf surfaces; avoid spraying in midday heat.',
      ],
      recoveryTimeline:
        'Existing spotted leaves will not turn green again, but new upper growth should emerge clean within 10–14 days once humidity splash and spore load are controlled.',
    },
    healthyCareAdvice: {
      watering: 'Water strictly at the root zone in the morning; avoid overhead sprinklers so foliage dries quickly.',
      sunlightAndAirflow: 'Provide 6–8 hours of direct sun and stake/prune suckers to keep open airflow through the canopy.',
      soilAndNutrition: 'Maintain balanced potassium and calcium; weak, nitrogen-starved plants succumb much faster to Alternaria.',
      preventiveChecklist: [
        'Rotate tomatoes and potatoes away from the same bed for 2–3 years.',
        'Space plants at least 60–75 cm apart.',
        'Remove all plant debris at the end of the growing season.',
      ],
    },
  },
  {
    id: 'tomato-late-blight',
    plantCommonName: 'Tomato',
    plantScientificName: 'Solanum lycopersicum',
    diseaseName: 'Late Blight (Phytophthora infestans)',
    isHealthy: false,
    pathogenType: 'Oomycete',
    severity: 'Critical',
    summary:
      'An aggressive water-mold infection causing irregular water-soaked dark blotches that rapidly turn dark brown/black, often with faint pale fuzz on leaf undersides in cool wet weather.',
    observedSymptoms: [
      'Irregular dark brown-black water-soaked blotches without crisp target rings',
      'Rapid collapse of leaf tissue and dark stem lesions',
      'Pale grayish-white sporulation ring visible under humid mornings',
    ],
    signature: {
      necrosisMin: 12,
      idealGreen: [15, 65],
      idealChlorosis: [3, 25],
      idealNecrosis: [12, 55],
      idealRust: [0, 5],
      idealPowdery: [0, 8],
      idealEdgeBrown: [6, 35],
      symptomTags: ['water_soaked'],
    },
    howToSolve: {
      immediateActions: [
        'Act within 24 hours: remove and seal infected leaves and stems in plastic bags before wind carries spores to neighboring beds.',
        'If main stems are blackened across most of the plant, pull and destroy the entire plant to save nearby tomatoes and potatoes.',
      ],
      organicRemedies: [
        'Apply OMRI-listed copper hydroxide or copper octanoate immediately to protect uninfected foliage before rain.',
      ],
      targetedTreatments: [
        'Use targeted oomycete-specific fungicides (such as mandipropamid, cyazofamid, or fluopicolide where registered) rotated with copper.',
        'Stop all overhead misting or watering immediately.',
      ],
      recoveryTimeline:
        'Late blight moves very fast in cool wet weather (15–22°C). Containment is successful if no new water-soaked lesions appear on fresh upper leaves after 5–7 days.',
    },
    healthyCareAdvice: {
      watering: 'Use drip irrigation only at dawn so leaves never stay wet overnight.',
      sunlightAndAirflow: 'Maximize sun exposure and greenhouse ventilation; avoid dense, shaded canopies.',
      soilAndNutrition: 'Avoid excessive quick-release nitrogen that creates lush, vulnerable tissue.',
      preventiveChecklist: [
        'Plant resistant varieties (e.g., Mountain Magic, Defiant, Iron Lady).',
        'Destroy volunteer potato/tomato plants early in spring.',
        'Inspect undersides of leaves weekly during rainy spells.',
      ],
    },
  },
  {
    id: 'tomato-bacterial-spot',
    plantCommonName: 'Tomato',
    plantScientificName: 'Solanum lycopersicum',
    diseaseName: 'Bacterial Leaf Spot (Xanthomonas spp.)',
    isHealthy: false,
    pathogenType: 'Bacterial',
    severity: 'High',
    summary:
      'Small, greasy dark specks that coalesce into ragged brown lesions with yellow halos, sometimes dropping out to leave shot-hole tears.',
    observedSymptoms: [
      'Numerous small dark brown-to-black specks (<3 mm) across the blade',
      'Yellowish halos merging into scorched leaf margins',
      'Rough, scabby spots may also appear on green fruit',
    ],
    signature: {
      idealGreen: [30, 75],
      idealChlorosis: [6, 32],
      idealNecrosis: [5, 28],
      idealRust: [0, 5],
      idealPowdery: [0, 4],
      idealEdgeBrown: [4, 22],
      symptomTags: ['yellow_halo', 'water_soaked'],
    },
    howToSolve: {
      immediateActions: [
        'Never touch or prune plants while leaves are wet with dew or rain—bacteria spread instantly on hands and tools.',
        'Remove severely affected lower foliage cleanly during dry midday hours.',
      ],
      organicRemedies: [
        'Apply fixed copper bactericide mixed with a plant-safe biopesticide every 5–7 days during warm, rainy weather.',
      ],
      targetedTreatments: [
        'Tank-mix copper + mancozeb (where legally permitted for home/farm use) to overcome copper-tolerant bacterial strains.',
      ],
      recoveryTimeline:
        'Bacteria cannot be cured inside existing lesions; success means halting new specks on fresh upper shoots over 10–14 days.',
    },
    healthyCareAdvice: {
      watering: 'Drip irrigate only; avoid working in beds after rain.',
      sunlightAndAirflow: 'Space plants generously and keep weeds clear around the base.',
      soilAndNutrition: 'Keep soil pH around 6.2–6.8 with steady organic matter.',
      preventiveChecklist: [
        'Source certified disease-free seeds or hot-water-treated seeds.',
        'Sanitize stakes and cages before reuse.',
      ],
    },
  },
  {
    id: 'potato-late-blight',
    plantCommonName: 'Potato',
    plantScientificName: 'Solanum tuberosum',
    diseaseName: 'Potato Late Blight (Phytophthora infestans)',
    isHealthy: false,
    pathogenType: 'Oomycete',
    severity: 'Critical',
    summary:
      'Dark purplish-black water-soaked lesions expanding rapidly across leaflets and stems, threatening tuber rot if spores wash into soil.',
    observedSymptoms: [
      'Dark water-soaked lesions along leaf margins and tips',
      'Rapid browning and collapse of leaflets',
      'Musty odor in heavily blighted foliage',
    ],
    signature: {
      idealGreen: [15, 62],
      idealChlorosis: [4, 25],
      idealNecrosis: [12, 50],
      idealRust: [0, 5],
      idealPowdery: [0, 7],
      idealEdgeBrown: [6, 35],
      symptomTags: ['water_soaked', 'edge_scorch'],
    },
    howToSolve: {
      immediateActions: [
        'Remove and bag infected leaves immediately; do not leave cut haulms on the soil.',
        'Hill soil firmly over potato rows to shield underground tubers from spores washing down.',
      ],
      organicRemedies: [
        'Apply copper-based protectant sprays ahead of cool, wet weather fronts.',
      ],
      targetedTreatments: [
        'If >50% of foliage is blighted near harvest, cut all vines at ground level and wait 14 days before digging tubers so skins set and spores die.',
      ],
      recoveryTimeline:
        'Stabilizes within 1 week if weather dries and protectant coverage is maintained on new shoots.',
    },
    healthyCareAdvice: {
      watering: 'Avoid evening irrigation; water early morning at furrow level.',
      sunlightAndAirflow: 'Plant in open, breezy sites with full sun.',
      soilAndNutrition: 'Ensure well-drained sandy-loam soil; never let water pool in potato rows.',
      preventiveChecklist: [
        'Always plant certified disease-free seed tubers (never grocery potatoes).',
        'Practice 3–4 year crop rotation out of Solanaceae.',
      ],
    },
  },
  {
    id: 'apple-scab',
    plantCommonName: 'Apple',
    plantScientificName: 'Malus domestica',
    diseaseName: 'Apple Scab (Venturia inaequalis)',
    isHealthy: false,
    pathogenType: 'Fungal',
    severity: 'Moderate',
    summary:
      'Velvety olive-green to dark brown-black scabby spots on apple leaves and fruit, causing premature leaf yellowing and drop.',
    observedSymptoms: [
      'Velvety olive-brown to black circular blotches on upper leaf surface',
      'Puckering or slight distortion around scab lesions',
      'Yellowing of heavily spotted leaves',
    ],
    signature: {
      idealGreen: [28, 72],
      idealChlorosis: [6, 30],
      idealNecrosis: [6, 32],
      idealRust: [0, 6],
      idealPowdery: [0, 6],
      idealEdgeBrown: [2, 18],
      symptomTags: ['yellow_halo', 'leaf_curl'],
    },
    howToSolve: {
      immediateActions: [
        'Rake and dispose of all fallen infected leaves to stop overwintering ascospores.',
        'Prune overcrowded interior water sprouts to dry the canopy faster after rain.',
      ],
      organicRemedies: [
        'Spray wettable sulfur or liquid copper soap at bud-break through early summer every 7–10 days during wet periods.',
      ],
      targetedTreatments: [
        'For orchard management, captan or myclobutanil rotated carefully prevents resistance.',
      ],
      recoveryTimeline:
        'Trees recover canopy vigor in 3–4 weeks once new summer shoots stay dry and protected.',
    },
    healthyCareAdvice: {
      watering: 'Water deeply at the drip line; keep sprinklers below the lower branches.',
      sunlightAndAirflow: 'Annual winter pruning for an open goblet/central-leader canopy is the single best defense.',
      soilAndNutrition: 'Mulch with compost in spring; avoid excessive late-summer nitrogen.',
      preventiveChecklist: [
        'Choose scab-resistant cultivars (Liberty, Enterprise, Honeycrisp crosses).',
        'Apply 5% urea foliar spray at leaf drop in autumn to speed leaf decomposition.',
      ],
    },
  },
  {
    id: 'apple-cedar-rust',
    plantCommonName: 'Apple',
    plantScientificName: 'Malus domestica',
    diseaseName: 'Cedar Apple Rust (Gymnosporangium juniperi-virginianae)',
    isHealthy: false,
    pathogenType: 'Fungal',
    severity: 'Moderate',
    summary:
      'Bright orange-yellow spots on upper leaf surfaces that develop tiny dark dots and raised cup-like spore structures underneath.',
    observedSymptoms: [
      'Distinct bright yellow-orange circular spots on leaves',
      'Tiny dark fruiting specks at center of orange spots',
      'Raised rust pustules on leaf undersides',
    ],
    signature: {
      rustMin: 4,
      idealGreen: [30, 75],
      idealChlorosis: [8, 30],
      idealNecrosis: [1, 15],
      idealRust: [4, 35],
      idealPowdery: [0, 5],
      idealEdgeBrown: [1, 14],
      symptomTags: ['orange_pustules', 'yellow_halo'],
    },
    howToSolve: {
      immediateActions: [
        'Inspect nearby Eastern red cedar or juniper trees within 300 meters for orange gelatinous galls in spring and prune them out.',
        'Remove severely rusted apple leaves if infection is localized.',
      ],
      organicRemedies: [
        'Apply sulfur or copper spray starting at pink-bud stage through petal fall.',
      ],
      targetedTreatments: [
        'Myclobutanil or triadimefon applied during spring spore release gives strong control on susceptible varieties.',
      ],
      recoveryTimeline:
        'Rust stops spreading once spring cedar gall spore release ends (usually mid-summer); healthy late shoots fill in normally.',
    },
    healthyCareAdvice: {
      watering: 'Deep weekly watering during dry fruit-set periods.',
      sunlightAndAirflow: 'Full sun and open pruning reduce leaf wetness duration.',
      soilAndNutrition: 'Balanced orchard fertilization with boron and calcium support.',
      preventiveChecklist: [
        'Avoid planting junipers/cedars directly upwind of apple trees.',
        'Plant rust-resistant apple cultivars like Redfree or Liberty.',
      ],
    },
  },
  {
    id: 'corn-common-rust',
    plantCommonName: 'Corn / Maize',
    plantScientificName: 'Zea mays',
    diseaseName: 'Common Corn Rust (Puccinia sorghi)',
    isHealthy: false,
    pathogenType: 'Fungal',
    severity: 'Moderate',
    summary:
      'Elongated cinnamon-brown to orange raised pustules scattered across both upper and lower corn leaf surfaces, turning dark brown as they mature.',
    observedSymptoms: [
      'Cinnamon-orange elongated pustules erupting through the leaf epidermis',
      'Dusty orange-brown spores when wiped with a white tissue',
      'Yellowing streaks along parallel corn veins',
    ],
    signature: {
      rustMin: 4,
      idealGreen: [28, 76],
      idealChlorosis: [6, 28],
      idealNecrosis: [2, 20],
      idealRust: [4, 38],
      idealPowdery: [0, 5],
      idealEdgeBrown: [2, 18],
      symptomTags: ['orange_pustules'],
    },
    howToSolve: {
      immediateActions: [
        'Check upper ear-leaf coverage: if rust is limited to lowest leaves near maturity, yield loss is minimal.',
        'Remove heavily infected lower leaves in small garden plots to lower local spore load.',
      ],
      organicRemedies: [
        'Apply neem oil or sulfur dust early if cool, humid weather persists on young sweet corn.',
      ],
      targetedTreatments: [
        'For high-value sweet corn before tasseling, strobilurin/triazole fungicides protect the critical ear leaf.',
      ],
      recoveryTimeline:
        'Common rust slows sharply once daytime temperatures exceed 28–30°C and humidity drops.',
    },
    healthyCareAdvice: {
      watering: 'Irrigate deeply at base; avoid evening overhead watering.',
      sunlightAndAirflow: 'Plant blocks for pollination with recommended row spacing so air moves through.',
      soilAndNutrition: 'Side-dress nitrogen at knee-high stage and ensure adequate potassium.',
      preventiveChecklist: [
        'Select rust-resistant hybrid sweet or field corn.',
        'Plant early so tasseling completes before peak late-summer rust winds.',
      ],
    },
  },
  {
    id: 'corn-northern-blight',
    plantCommonName: 'Corn / Maize',
    plantScientificName: 'Zea mays',
    diseaseName: 'Northern Corn Leaf Blight (Exserohilum turcicum)',
    isHealthy: false,
    pathogenType: 'Fungal',
    severity: 'High',
    summary:
      'Long, elliptical gray-green to tan "cigar-shaped" lesions (3–15 cm) running parallel to leaf veins, drying out the canopy prematurely.',
    observedSymptoms: [
      'Elongated cigar-shaped gray-green or tan necrotic streaks',
      'Lesions merging into large dead leaf blades',
      'Lower leaves drying out upward toward the ear',
    ],
    signature: {
      idealGreen: [22, 68],
      idealChlorosis: [5, 25],
      idealNecrosis: [8, 42],
      idealRust: [0, 6],
      idealPowdery: [0, 8],
      idealEdgeBrown: [5, 30],
      symptomTags: ['edge_scorch', 'water_soaked'],
    },
    howToSolve: {
      immediateActions: [
        'Monitor the ear leaf and leaves above it; protect them before grain fill if infection climbs past lower leaves.',
        'Strip and dispose of badly blighted lower leaves in small plots.',
      ],
      organicRemedies: [
        'Apply Bacillus subtilis or copper protectants on young sweet corn during prolonged dewy periods.',
      ],
      targetedTreatments: [
        'Azoxystrobin + propiconazole applied at tasseling protects yield when disease threatens upper leaves.',
      ],
      recoveryTimeline:
        'Stopping upward spread protects ear-filling leaves for the remaining 4–6 weeks to harvest.',
    },
    healthyCareAdvice: {
      watering: 'Consistent soil moisture during tasseling reduces plant stress.',
      sunlightAndAirflow: 'Avoid overly dense planting.',
      soilAndNutrition: 'Balanced NPK + zinc prevents weakened stalk and leaf tissue.',
      preventiveChecklist: [
        'Rotate corn out of infected residue for at least 1–2 years.',
        'Till under or remove infected corn stalks after harvest.',
      ],
    },
  },
  {
    id: 'grape-black-rot',
    plantCommonName: 'Grapevine',
    plantScientificName: 'Vitis vinifera',
    diseaseName: 'Grape Black Rot (Guignardia bidwellii)',
    isHealthy: false,
    pathogenType: 'Fungal',
    severity: 'High',
    summary:
      'Reddish-brown circular spots with dark borders on grape leaves containing tiny black pinhead pycnidia dots in a ring, capable of mummifying berries.',
    observedSymptoms: [
      'Tan-to-reddish-brown circular spots with crisp dark margins',
      'Tiny black pepper-like dots arranged near the edge of spots',
      'Shriveled dark "mummy" berries if clusters are infected',
    ],
    signature: {
      idealGreen: [28, 72],
      idealChlorosis: [4, 24],
      idealNecrosis: [6, 32],
      idealRust: [1, 14],
      idealPowdery: [0, 5],
      idealEdgeBrown: [3, 20],
      symptomTags: ['concentric_rings', 'yellow_halo'],
    },
    howToSolve: {
      immediateActions: [
        'Pick off and destroy all spotted leaves and any dark mummified grape berries on the vine or ground.',
        'Thin excess shoots around fruit clusters so sunlight reaches the clusters directly.',
      ],
      organicRemedies: [
        'Spray copper + sulfur (check cultivar sensitivity—avoid sulfur on Concord/Labrusca types) before rain.',
      ],
      targetedTreatments: [
        'Myclobutanil or mancozeb applied from pre-bloom through 4 weeks post-bloom protects developing berries.',
      ],
      recoveryTimeline:
        'Leaf spots stop multiplying within 10–14 days of strict sanitation and dry canopy airflow.',
    },
    healthyCareAdvice: {
      watering: 'Deep root watering; vines prefer dry foliage and well-drained soil.',
      sunlightAndAirflow: 'Trellis vines high and pull leaves shading grape clusters.',
      soilAndNutrition: 'Avoid excessive nitrogen which creates dense, damp shade.',
      preventiveChecklist: [
        'Never leave shriveled mummy berries hanging over winter.',
        'Keep weeds cut short beneath the trellis.',
      ],
    },
  },
  {
    id: 'powdery-mildew-general',
    plantCommonName: 'Rose / Cucurbit / Garden Leaf',
    plantScientificName: 'Erysiphales (Podosphaera / Erysiphe spp.)',
    diseaseName: 'Powdery Mildew',
    isHealthy: false,
    pathogenType: 'Fungal',
    severity: 'Moderate',
    summary:
      'Chalky white or grayish talcum-like fungal powder coating upper leaf surfaces, young shoots, and buds, thriving in warm days and cool humid nights.',
    observedSymptoms: [
      'White or pale-gray powdery patches on leaf surface',
      'Slight curling or distortion of tender young leaves',
      'Leaves eventually yellowing beneath heavy white mycelium',
    ],
    signature: {
      powderyMin: 7,
      idealGreen: [25, 74],
      idealChlorosis: [3, 24],
      idealNecrosis: [0, 12],
      idealRust: [0, 5],
      idealPowdery: [7, 45],
      idealEdgeBrown: [1, 14],
      symptomTags: ['white_powder', 'leaf_curl'],
    },
    howToSolve: {
      immediateActions: [
        'Prune off the most heavily whitened shoots and dispose of them in sealed trash.',
        'Move potted plants out of stagnant corners into brighter, breezy locations.',
      ],
      organicRemedies: [
        'Potassium bicarbonate spray (1 tbsp per gallon water + 1 tsp horticultural oil or mild soap) kills surface mycelium quickly.',
        'Neem oil or diluted milk spray (40% milk / 60% water) in bright morning light helps suppress mild infections.',
      ],
      targetedTreatments: [
        'Wettable sulfur (never apply within 14 days of oil sprays or above 30°C) or myclobutanil for persistent ornamental/vine outbreaks.',
      ],
      recoveryTimeline:
        'White powder visibly dries and clears within 3–5 days of bicarbonate/oil treatment; repeat in 7 days to catch remaining spores.',
    },
    healthyCareAdvice: {
      watering: 'Water deeply at the soil level—paradoxically, drought-stressed roots make plants more prone to powdery mildew.',
      sunlightAndAirflow: 'Maximize morning sun and cross-breeze; avoid overcrowding.',
      soilAndNutrition: 'Switch from high-nitrogen quick fertilizer to balanced slow-release nutrition.',
      preventiveChecklist: [
        'Select mildew-resistant cultivars.',
        'Clean up fallen foliage around roses, squash, and grapes in autumn.',
      ],
    },
  },
  {
    id: 'rose-black-spot',
    plantCommonName: 'Rose',
    plantScientificName: 'Rosa spp.',
    diseaseName: 'Rose Black Spot (Diplocarpon rosae)',
    isHealthy: false,
    pathogenType: 'Fungal',
    severity: 'Moderate',
    summary:
      'Circular jet-black spots with feathery or fringed margins surrounded by bright yellow tissue, causing rapid defoliation.',
    observedSymptoms: [
      'Black circular lesions with feathery edges',
      'Bright yellow halo turning entire leaflets yellow',
      'Premature drop of lower rose leaves',
    ],
    signature: {
      idealGreen: [22, 68],
      idealChlorosis: [10, 42],
      idealNecrosis: [6, 30],
      idealRust: [0, 6],
      idealPowdery: [0, 6],
      idealEdgeBrown: [2, 18],
      symptomTags: ['yellow_halo', 'uniform_yellow'],
    },
    howToSolve: {
      immediateActions: [
        'Pick off every spotted and yellowed leaflet on the bush AND collect all fallen leaves from the mulch.',
        'Apply fresh 5 cm bark mulch to bury overwintered spores.',
      ],
      organicRemedies: [
        'Spray neem oil or copper octanoate every 7–10 days, coating both leaf sides.',
      ],
      targetedTreatments: [
        'Tebuconazole or triforine formulations work well for valuable exhibition roses when rotated.',
      ],
      recoveryTimeline:
        'New reddish rose shoots emerge clean within 2–3 weeks once fallen leaves are cleared and foliage stays dry.',
    },
    healthyCareAdvice: {
      watering: 'Soak the base deeply twice a week; never wet rose leaves in the evening.',
      sunlightAndAirflow: '6+ hours of morning sun dries dew rapidly.',
      soilAndNutrition: 'Feed with balanced rose fertilizer + compost in spring and mid-summer.',
      preventiveChecklist: [
        'Prune center canes outward into an open vase shape.',
        'Plant Knock Out or disease-resistant shrub roses.',
      ],
    },
  },
  {
    id: 'bell-pepper-bacterial-spot',
    plantCommonName: 'Bell Pepper / Chili',
    plantScientificName: 'Capsicum annuum',
    diseaseName: 'Bacterial Leaf Spot (Xanthomonas campestris)',
    isHealthy: false,
    pathogenType: 'Bacterial',
    severity: 'High',
    summary:
      'Water-soaked dark spots turning purplish-brown with raised scabs underneath and yellow borders, triggering heavy pepper leaf drop.',
    observedSymptoms: [
      'Small dark brown/purplish lesions with pale yellow margins',
      'Slightly raised blister-like bumps on leaf undersides',
      'Yellowing and shedding of older pepper leaves',
    ],
    signature: {
      idealGreen: [30, 74],
      idealChlorosis: [7, 32],
      idealNecrosis: [5, 25],
      idealRust: [0, 5],
      idealPowdery: [0, 4],
      idealEdgeBrown: [3, 18],
      symptomTags: ['water_soaked', 'yellow_halo'],
    },
    howToSolve: {
      immediateActions: [
        'Isolate infected potted peppers and remove spotted leaves only when foliage is completely dry.',
        'Wash hands and tools thoroughly before touching healthy pepper or tomato plants.',
      ],
      organicRemedies: [
        'Spray copper soap every 5–7 days during humid weather to halt bacterial spread.',
      ],
      targetedTreatments: [
        'Copper hydroxide combined with biological Bacillus amyloliquefaciens gives improved protection.',
      ],
      recoveryTimeline:
        'Leaf drop slows within 7–10 days once overhead moisture stops and new upper canopy stays clean.',
    },
    healthyCareAdvice: {
      watering: 'Use bottom watering or drip emitters; peppers dislike soggy roots and wet leaves.',
      sunlightAndAirflow: 'Warm sun (21–29°C) with gentle airflow.',
      soilAndNutrition: 'Avoid overfeeding nitrogen; supply steady calcium and magnesium.',
      preventiveChecklist: [
        'Rotate away from peppers/tomatoes for 3 years.',
        'Inspect transplants carefully before planting out.',
      ],
    },
  },
  {
    id: 'citrus-canker',
    plantCommonName: 'Citrus / Lemon',
    plantScientificName: 'Citrus spp.',
    diseaseName: 'Citrus Canker (Xanthomonas citri)',
    isHealthy: false,
    pathogenType: 'Bacterial',
    severity: 'High',
    summary:
      'Raised corky tan-brown crater-like lesions surrounded by a distinct oily yellow halo, visible on both sides of glossy citrus leaves.',
    observedSymptoms: [
      'Raised corky brown scabs visible on both top and bottom of leaf',
      'Bright yellow halo encircling each corky lesion',
      'Twisted or ragged leaf tissue around older spots',
    ],
    signature: {
      idealGreen: [35, 78],
      idealChlorosis: [6, 28],
      idealNecrosis: [4, 22],
      idealRust: [1, 12],
      idealPowdery: [0, 4],
      idealEdgeBrown: [1, 14],
      symptomTags: ['yellow_halo', 'concentric_rings'],
    },
    howToSolve: {
      immediateActions: [
        'Prune out infected twigs and leaves during dry weather and bag them.',
        'Control citrus leafminer pests (neem or spinosad), as leafminer tunnels let canker bacteria enter effortlessly.',
      ],
      organicRemedies: [
        'Apply copper-based spray on new spring and summer growth flushes as leaves expand.',
      ],
      targetedTreatments: [
        'Time liquid copper sprays at 21-day intervals while young citrus shoots are expanding.',
      ],
      recoveryTimeline:
        'Mature citrus leaves harden off and become naturally resistant after 4–6 weeks; protecting fresh flushes keeps trees productive.',
    },
    healthyCareAdvice: {
      watering: 'Deep, infrequent watering; let top 5 cm of soil dry between waterings.',
      sunlightAndAirflow: 'Full sun (6–8+ hours) and windbreaks to stop wind-driven rain splash.',
      soilAndNutrition: 'Use citrus-specific fertilizer rich in iron, zinc, and magnesium.',
      preventiveChecklist: [
        'Never propagate cuttings from symptomatic trees.',
        'Check local agricultural advisories if citrus canker is a quarantined pest in your region.',
      ],
    },
  },
  {
    id: 'strawberry-leaf-scorch',
    plantCommonName: 'Strawberry',
    plantScientificName: 'Fragaria × ananassa',
    diseaseName: 'Strawberry Leaf Scorch / Leaf Spot',
    isHealthy: false,
    pathogenType: 'Fungal',
    severity: 'Moderate',
    summary:
      'Dark purplish-red blotches scattered across strawberry leaves that merge until entire leaves turn reddish-brown and crispy.',
    observedSymptoms: [
      'Irregular dark purple to reddish-brown blotches',
      'Leaves curling upward and drying to a scorched look',
      'Older outer leaves turning necrotic first',
    ],
    signature: {
      idealGreen: [25, 70],
      idealChlorosis: [4, 24],
      idealNecrosis: [7, 35],
      idealRust: [2, 16],
      idealPowdery: [0, 5],
      idealEdgeBrown: [5, 28],
      symptomTags: ['edge_scorch', 'yellow_halo'],
    },
    howToSolve: {
      immediateActions: [
        'Clip off heavily scorched outer leaves right down to the crown without harming central emerging leaves.',
        'Tuck clean straw under berry crowns to separate leaves from damp soil.',
      ],
      organicRemedies: [
        'Spray copper or potassium bicarbonate after renovation/cleanup.',
      ],
      targetedTreatments: [
        'Captan or azoxystrobin post-harvest renovation sprays reduce inoculum for next season.',
      ],
      recoveryTimeline:
        'Fresh green crown leaves replace damaged outer leaves within 2–3 weeks.',
    },
    healthyCareAdvice: {
      watering: 'Soaker hose beneath straw mulch; keep berries and leaves dry.',
      sunlightAndAirflow: 'Full sun and 30–40 cm plant spacing.',
      soilAndNutrition: 'Slightly acidic soil (pH 5.5–6.5) with compost.',
      preventiveChecklist: [
        'Renovate strawberry beds after fruiting by mowing old foliage and thinning runners.',
        'Replace beds every 3–4 years.',
      ],
    },
  },
  {
    id: 'mango-anthracnose',
    plantCommonName: 'Mango',
    plantScientificName: 'Mangifera indica',
    diseaseName: 'Mango Anthracnose (Colletotrichum gloeosporioides)',
    isHealthy: false,
    pathogenType: 'Fungal',
    severity: 'High',
    summary:
      'Irregular dark brown to black sunken spots on young mango leaves and panicles, often starting near tips and margins during humid weather.',
    observedSymptoms: [
      'Dark brown-black irregular spots coalescing along leaf tips and edges',
      'Shot-hole tearing as dry dead tissue falls away',
      'Young reddish flush leaves distorted or blackened',
    ],
    signature: {
      idealGreen: [28, 72],
      idealChlorosis: [4, 22],
      idealNecrosis: [8, 36],
      idealRust: [0, 8],
      idealPowdery: [0, 5],
      idealEdgeBrown: [6, 30],
      symptomTags: ['edge_scorch', 'water_soaked'],
    },
    howToSolve: {
      immediateActions: [
        'Prune dead twigs, blighted flower panicles, and heavily spotted leaves to open the tree crown.',
        'Clear fallen leaves under the tree canopy.',
      ],
      organicRemedies: [
        'Spray copper oxychloride or copper hydroxide as new leaf flushes and flower panicles emerge.',
      ],
      targetedTreatments: [
        'Rotate copper with azoxystrobin or prochloraz before flowering and during early fruit set in rainy tropics.',
      ],
      recoveryTimeline:
        'New growth flushes emerge healthy within 3–4 weeks once dry airflow and copper shield are active.',
    },
    healthyCareAdvice: {
      watering: 'Avoid misting foliage; water deeply only during prolonged drought and fruit swell.',
      sunlightAndAirflow: 'Skirt-prune low branches and thin crossing interior limbs after harvest.',
      soilAndNutrition: 'Balanced potassium and trace zinc/boron strengthen leaf cuticle.',
      preventiveChecklist: [
        'Prune annually right after harvest.',
        'Do not crowd mango saplings under dense shade trees.',
      ],
    },
  },
  {
    id: 'rice-brown-spot',
    plantCommonName: 'Rice',
    plantScientificName: 'Oryza sativa',
    diseaseName: 'Rice Brown Spot (Bipolaris oryzae)',
    isHealthy: false,
    pathogenType: 'Fungal',
    severity: 'Moderate',
    summary:
      'Oval sesame-seed-shaped brown lesions with gray centers and yellow halos across rice blades, strongly linked to potassium/silicon-poor soils.',
    observedSymptoms: [
      'Oval dark-brown lesions resembling sesame seeds along leaf blades',
      'Faint yellow halo surrounding individual brown spots',
      'Premature yellowing of lower rice leaves',
    ],
    signature: {
      idealGreen: [25, 70],
      idealChlorosis: [8, 34],
      idealNecrosis: [6, 30],
      idealRust: [2, 14],
      idealPowdery: [0, 5],
      idealEdgeBrown: [4, 22],
      symptomTags: ['yellow_halo', 'concentric_rings'],
    },
    howToSolve: {
      immediateActions: [
        'Correct nutrient deficiency immediately—brown spot is a classic indicator of low potassium, nitrogen imbalance, or water stress.',
        'Ensure paddy water depth is steady rather than cycling between bone-dry and flooded.',
      ],
      organicRemedies: [
        'Apply Pseudomonas fluorescens bio-control spray and supplement soil with potassium silicate or wood ash/compost.',
      ],
      targetedTreatments: [
        'In severe grain-stage outbreaks, propiconazole or azoxystrobin helps protect the flag leaf.',
      ],
      recoveryTimeline:
        'New tillers and upper flag leaves recover cleanly within 14 days after potassium correction and moisture stabilization.',
    },
    healthyCareAdvice: {
      watering: 'Maintain consistent shallow irrigation without severe drought stress.',
      sunlightAndAirflow: 'Avoid over-dense seeding.',
      soilAndNutrition: 'Incorporate silicon (rice husk ash) and balanced K + N split doses.',
      preventiveChecklist: [
        'Treat seed with hot water (53–54°C for 10 min) or bio-protectant before sowing.',
        'Remove infected straw stubble post-harvest.',
      ],
    },
  },
  {
    id: 'viral-mosaic-curl',
    plantCommonName: 'Tomato / Pepper / Cucumber / Garden Plant',
    plantScientificName: 'Tobamovirus / Begomovirus',
    diseaseName: 'Mosaic Virus / Leaf Curl Complex',
    isHealthy: false,
    pathogenType: 'Viral',
    severity: 'High',
    summary:
      'Mottled light-green and dark-green mosaic patches, leaf cupping, blistering, and stunted distorted growth spread by whiteflies, aphids, or contaminated hands.',
    observedSymptoms: [
      'Patchy light-green and yellow-green mosaic mottling',
      'Upward or downward leaf curling, puckering, and narrow shoestring blades',
      'Stunted upper shoots without obvious fungal powder or wet rot',
    ],
    signature: {
      idealGreen: [32, 74],
      idealChlorosis: [12, 42],
      idealNecrosis: [0, 10],
      idealRust: [0, 4],
      idealPowdery: [0, 6],
      idealEdgeBrown: [0, 12],
      symptomTags: ['leaf_curl', 'uniform_yellow'],
    },
    howToSolve: {
      immediateActions: [
        'There is no chemical cure for plant viruses—immediately isolate or pull severely curled/mosaic plants so vectors do not spread it to the rest of your crop.',
        'Wash hands with milk/soap and disinfect tools before touching healthy plants (especially if handling tobacco/tomatoes).',
      ],
      organicRemedies: [
        'Target the insect vectors (aphids, whiteflies, thrips) using insecticidal soap, neem oil, and yellow sticky traps.',
      ],
      targetedTreatments: [
        'Cover healthy neighboring seedlings with fine insect-exclusion mesh (40-mesh) to block whitefly transmission.',
      ],
      recoveryTimeline:
        'Viral infection is systemic and permanent in affected plants; removing infected hosts stops herd spread immediately.',
    },
    healthyCareAdvice: {
      watering: 'Consistent moisture reduces stress that attracts sap-sucking insects.',
      sunlightAndAirflow: 'Use reflective silver mulch to confuse aphids and whiteflies.',
      soilAndNutrition: 'Do not over-apply nitrogen; tender sappy shoots attract aphids.',
      preventiveChecklist: [
        'Choose virus-resistant cultivars (labeled TMV, TYLCV, ToMV resistant).',
        'Control weeds around garden borders that harbor viruses.',
      ],
    },
  },
  {
    id: 'nutrient-chlorosis-iron-nitrogen',
    plantCommonName: 'Houseplant / Garden Crop',
    plantScientificName: 'Chlorosis / Abiotic Stress',
    diseaseName: 'Nutrient Deficiency (Chlorosis — Nitrogen / Iron / Magnesium)',
    isHealthy: false,
    pathogenType: 'Nutrient / Abiotic',
    severity: 'Low',
    summary:
      'Uniform pale yellowing across older leaves (Nitrogen) or bright yellow blades with crisp green veins on young leaves (Iron/Magnesium), without infectious spots.',
    observedSymptoms: [
      'Widespread yellowing across the leaf blade with few or no necrotic spots',
      'Green veins contrasting against yellow interveinal tissue (or uniform pale yellow)',
      'No fungal powder, rust bumps, or water-soaked blotches',
    ],
    signature: {
      chlorosisMin: 18,
      necrosisMax: 7,
      idealGreen: [15, 62],
      idealChlorosis: [18, 70],
      idealNecrosis: [0, 7],
      idealRust: [0, 6],
      idealPowdery: [0, 5],
      idealEdgeBrown: [0, 14],
      symptomTags: ['uniform_yellow'],
    },
    howToSolve: {
      immediateActions: [
        'Check soil moisture first: soggy, waterlogged roots suffocate and mimic nitrogen/iron deficiency even in fertile soil.',
        'Test soil/potting mix pH—alkaline soil (>7.2) locks out iron.',
      ],
      organicRemedies: [
        'Apply liquid fish emulsion, worm-casting tea, or chelated iron (Fe-EDDHA) depending on whether old leaves (N) or new leaves (Fe) are yellow.',
        'For interveinal yellowing on older leaves (Magnesium), drench with 1 tsp Epsom salt per liter of water.',
      ],
      targetedTreatments: [
        'Repot rootbound container plants with fresh aerated potting mix and balanced slow-release fertilizer.',
      ],
      recoveryTimeline:
        'Young chlorotic leaves begin greening up within 5–10 days after pH and root-oxygen correction; fully aged yellow lower leaves may eventually shed.',
    },
    healthyCareAdvice: {
      watering: 'Ensure drainage holes are clear; water only when top 2–4 cm of soil feels dry.',
      sunlightAndAirflow: 'Bright indirect light for houseplants; full sun for fruiting veggies.',
      soilAndNutrition: 'Feed lightly every 2–4 weeks during active spring/summer growth.',
      preventiveChecklist: [
        'Flush potted soil every 2 months to prevent fertilizer salt buildup.',
        'Refresh top compost layer each spring.',
      ],
    },
  },
  {
    id: 'abiotic-leaf-scorch',
    plantCommonName: 'Houseplant / Orchard / Garden Plant',
    plantScientificName: 'Abiotic / Environmental Stress',
    diseaseName: 'Leaf Scorch / Tip Burn (Heat, Salt, or Drought Stress)',
    isHealthy: false,
    pathogenType: 'Nutrient / Abiotic',
    severity: 'Low',
    summary:
      'Dry, papery brown margins and burnt leaf tips caused by underwatering, hot dry wind, sudden sunburn, or excess fertilizer salts.',
    observedSymptoms: [
      'Crispy brown or tan margins and pointed tips',
      'Healthy green interior tissue separated cleanly from dry edges',
      'No powdery coating or spreading concentric fungal rings',
    ],
    signature: {
      edgeBrownMin: 7,
      idealGreen: [35, 80],
      idealChlorosis: [2, 22],
      idealNecrosis: [3, 24],
      idealRust: [0, 8],
      idealPowdery: [0, 4],
      idealEdgeBrown: [7, 45],
      symptomTags: ['edge_scorch'],
    },
    howToSolve: {
      immediateActions: [
        'Check root moisture deeply—both bone-dry soil and salt-burned roots block water from reaching leaf tips.',
        'Flush container pots thoroughly with clean rainwater or filtered water 2–3 times to wash out accumulated salts.',
      ],
      organicRemedies: [
        'Move scorched indoor plants slightly back from harsh west-facing glass or shield outdoor seedlings with 30% shade cloth during heatwaves.',
        'Trim only the dead brown tip margins cleanly with sharp sterile scissors if desired for aesthetics.',
      ],
      targetedTreatments: [
        'Pause all synthetic fertilizers for 3 weeks until root hydration recovers.',
      ],
      recoveryTimeline:
        'Burnt tips do not regenerate, but new leaves unfurl crisp and green within 2–3 weeks of moisture and shade stabilization.',
    },
    healthyCareAdvice: {
      watering: 'Water deeply and evenly rather than shallow daily splashes.',
      sunlightAndAirflow: 'Acclimate indoor/greenhouse plants gradually over 7–10 days before moving into full sun.',
      soilAndNutrition: 'Use half-strength liquid fertilizer and avoid hard tap water for sensitive tropicals.',
      preventiveChecklist: [
        'Mulch outdoor root zones to keep soil cool.',
        'Keep tropical foliage away from AC vents and radiator drafts.',
      ],
    },
  },
  {
    id: 'leaf-galls-mite-blisters',
    plantCommonName: 'Tree / Shrub / Garden Foliage',
    plantScientificName: 'Eriophyidae / Gall Mites & Psyllids',
    diseaseName: 'Leaf Galls / Eriophyid Mite Blisters',
    isHealthy: false,
    pathogenType: 'Pest / Mite',
    severity: 'Low',
    summary:
      'Raised wart-like, nipple-shaped, or blistered bumps across the leaf surface triggered by microscopic gall mites or tiny insects feeding on young expanding tissue. Rarely fatal to mature plants.',
    observedSymptoms: [
      'Clusters of raised green, tan, or reddish-brown wart-like galls on the leaf blade',
      'Surrounding leaf blade stays mostly green rather than rotting',
      'Slightly puckered or textured tissue around gall clusters',
    ],
    signature: {
      idealGreen: [58, 86],
      idealChlorosis: [6, 22],
      idealNecrosis: [1, 10],
      idealRust: [1, 10],
      idealPowdery: [0, 5],
      idealEdgeBrown: [0, 10],
      symptomTags: ['raised_galls', 'leaf_curl'],
    },
    howToSolve: {
      immediateActions: [
        'Do NOT spray fungicides—leaf galls are caused by mites/insects, not fungi, and existing galls will not flatten once formed.',
        'If only a few leaves on a small shrub or sapling are affected, prune and bag those leaves cleanly.',
      ],
      organicRemedies: [
        'For heavy annual outbreaks on young plants, apply dormant horticultural oil in late winter/early spring right before bud-break to target overwintering mites.',
        'Encourage natural predators (ladybugs, lacewings, predatory mites) by avoiding broad-spectrum insecticides.',
      ],
      targetedTreatments: [
        'For high-value ornamental shrubs, targeted miticide/horticultural oil timed exactly at spring leaf-bud swell prevents new galls next season; spraying after galls form has little effect because mites are sealed inside.',
      ],
      recoveryTimeline:
        'Mature trees and shrubs tolerate leaf galls well; current leaves stay functional, and new flushes emerge smooth once spring bud-break pressure passes.',
    },
    healthyCareAdvice: {
      watering: 'Deep watering during dry periods keeps trees vigorous and unbothered by cosmetic galls.',
      sunlightAndAirflow: 'Maintain normal sun and clean canopy airflow.',
      soilAndNutrition: 'Avoid excessive quick-release nitrogen that produces overly soft, extended spring flushes.',
      preventiveChecklist: [
        'Rake and dispose of fallen gall-covered leaves in autumn.',
        'Inspect new spring buds early before galls seal.',
      ],
    },
  },
  {
    id: 'healthy-leaf',
    plantCommonName: 'Healthy Plant Foliage',
    plantScientificName: 'Vigorous Chlorophyll Tissue',
    diseaseName: 'Healthy Leaf — No Disease Detected',
    isHealthy: true,
    pathogenType: 'Healthy',
    severity: 'None',
    summary:
      'Strong chlorophyll saturation, clean uniform blade surface, and minimal necrotic or chlorotic anomalies. The leaf appears healthy and vigorous.',
    observedSymptoms: [
      'Uniform rich green chlorophyll coloration',
      'Intact leaf margins without blight, rust pustules, or powdery mildew',
      'Clear structural veins and turgid tissue',
    ],
    signature: {
      healthyOnly: true,
      idealGreen: [62, 100],
      idealChlorosis: [0, 9],
      idealNecrosis: [0, 3.5],
      idealRust: [0, 2.5],
      idealPowdery: [0, 4],
      idealEdgeBrown: [0, 5],
      symptomTags: ['healthy_green'],
    },
    howToSolve: {
      immediateActions: [
        'No curative treatment needed! Continue routine weekly leaf inspections on both upper and lower leaf surfaces.',
      ],
      organicRemedies: [
        'Optional preventive boost: apply diluted compost tea or seaweed extract monthly to maintain resilient plant immunity.',
      ],
      targetedTreatments: [
        'Do not spray unnecessary fungicides or bactericides on healthy foliage—preserve beneficial leaf-surface microbes and pollinators.',
      ],
      recoveryTimeline: 'Plant is already in healthy condition. Maintain steady care.',
    },
    healthyCareAdvice: {
      watering: 'Water at the soil base in the morning when the top 2–3 cm of soil feels dry.',
      sunlightAndAirflow: 'Match species light needs and keep gentle air circulation around foliage.',
      soilAndNutrition: 'Top-dress with organic compost each season and follow balanced feeding schedules.',
      preventiveChecklist: [
        'Inspect undersides of leaves once a week for early aphids, mites, or spores.',
        'Sanitize pruning shears between different plants.',
        'Mulch root zones to keep moisture even and block soil splash.',
      ],
    },
  },
];
