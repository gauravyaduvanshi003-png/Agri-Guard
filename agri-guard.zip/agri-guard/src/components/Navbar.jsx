import { Leaf, BookOpen, History, Settings, ShieldCheck } from 'lucide-react';

export default function Navbar({
  activeTab,
  setActiveTab,
  cloudReady,
  historyCount,
  onOpenSettings,
}) {
  return (
    <header className="navbar">
      <div className="navbar-inner">
        <div className="brand">
          <div className="brand-icon" aria-hidden="true">
            <ShieldCheck size={24} />
          </div>
          <div>
            <h1 className="brand-title">Agri Guard</h1>
            <div className="brand-sub">Plant Leaf Disease Detection &amp; Recovery</div>
          </div>
        </div>

        <nav className="nav-tabs" aria-label="Primary navigation">
          <button
            type="button"
            className={`nav-tab ${activeTab === 'scanner' ? 'active' : ''}`}
            onClick={() => setActiveTab('scanner')}
          >
            <Leaf size={16} />
            Leaf Scanner
          </button>
          <button
            type="button"
            className={`nav-tab ${activeTab === 'library' ? 'active' : ''}`}
            onClick={() => setActiveTab('library')}
          >
            <BookOpen size={16} />
            Disease Guide
          </button>
          <button
            type="button"
            className={`nav-tab ${activeTab === 'history' ? 'active' : ''}`}
            onClick={() => setActiveTab('history')}
          >
            <History size={16} />
            History ({historyCount})
          </button>
        </nav>

        <div className="nav-actions">
          <button
            type="button"
            className="engine-pill"
            onClick={onOpenSettings}
            title="Configure AI Vision engine & API settings"
          >
            <span className={`dot ${cloudReady ? 'cloud' : 'local'}`} />
            <span>{cloudReady ? 'Gemini Vision AI Ready' : 'Local Optical Mode'}</span>
            <Settings size={14} />
          </button>
        </div>
      </div>
    </header>
  );
}
