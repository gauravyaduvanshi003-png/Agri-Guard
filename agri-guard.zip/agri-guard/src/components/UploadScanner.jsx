import { useRef, useState, useEffect } from 'react';
import {
  Camera,
  Upload,
  ScanSearch,
  RotateCcw,
  Sparkles,
  X,
  Aperture,
} from 'lucide-react';
import { PLANT_SPECIES_OPTIONS, SYMPTOM_CHIPS } from '../data/diseases.js';

export default function UploadScanner({
  imageSrc,
  onSelectImage,
  plantHint,
  setPlantHint,
  symptomsHint,
  setSymptomsHint,
  onAnalyze,
  isAnalyzing,
  samples,
  onSelectSample,
  onClear,
}) {
  const fileInputRef = useRef(null);
  const videoRef = useRef(null);
  const streamRef = useRef(null);

  const [isDragging, setIsDragging] = useState(false);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [cameraError, setCameraError] = useState('');

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  function stopCamera() {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraOpen(false);
  }

  async function openCamera() {
    setCameraError('');
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraError('Live camera API is unavailable in this browser. Use "Upload Photo" to take a picture on mobile.');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' } },
        audio: false,
      });
      streamRef.current = stream;
      setCameraOpen(true);
      requestAnimationFrame(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      });
    } catch (err) {
      setCameraError(
        err?.message || 'Camera permission denied. You can still upload a leaf photo directly.'
      );
    }
  }

  function captureFrame() {
    const video = videoRef.current;
    if (!video || !video.videoWidth) return;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
    stopCamera();
    onSelectImage(dataUrl, 'image/jpeg');
  }

  function handleFile(file) {
    if (!file || !file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        onSelectImage(reader.result, file.type || 'image/jpeg');
      }
    };
    reader.readAsDataURL(file);
  }

  function toggleSymptom(id) {
    if (symptomsHint.includes(id)) {
      setSymptomsHint(symptomsHint.filter((s) => s !== id));
    } else {
      setSymptomsHint([...symptomsHint, id]);
    }
  }

  return (
    <section className="card no-print">
      <div className="card-header">
        <h2 className="card-title">
          <Camera size={19} />
          1. Capture or Upload Leaf
        </h2>
        {imageSrc && (
          <button type="button" className="btn btn-ghost" onClick={onClear}>
            <RotateCcw size={15} />
            Reset
          </button>
        )}
      </div>

      <div className="card-body">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          style={{ display: 'none' }}
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) handleFile(file);
            e.target.value = '';
          }}
        />

        {cameraOpen ? (
          <div>
            <div className="preview-box">
              <video ref={videoRef} autoPlay playsInline muted />
              <div className="preview-toolbar">
                <button type="button" className="icon-chip" onClick={stopCamera}>
                  <X size={14} /> Close
                </button>
              </div>
            </div>
            <div className="action-row">
              <button type="button" className="btn btn-emerald" onClick={captureFrame}>
                <Aperture size={17} />
                Snap Leaf Photo
              </button>
            </div>
          </div>
        ) : imageSrc ? (
          <div className="preview-box">
            <img src={imageSrc} alt="Selected plant leaf" />
            <div className="preview-toolbar">
              <button
                type="button"
                className="icon-chip"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload size={13} /> Change
              </button>
            </div>
          </div>
        ) : (
          <div
            className={`dropzone ${isDragging ? 'dragging' : ''}`}
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              const file = e.dataTransfer.files?.[0];
              if (file) handleFile(file);
            }}
            onClick={() => fileInputRef.current?.click()}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') fileInputRef.current?.click();
            }}
          >
            <div className="dropzone-icon">
              <Upload size={24} />
            </div>
            <div style={{ fontWeight: 700, fontSize: '1rem', color: 'var(--forest)' }}>
              Drop a leaf photo here, or click to browse
            </div>
            <div style={{ fontSize: '0.84rem', color: 'var(--text-muted)', marginTop: 4 }}>
              Best results: single leaf in natural daylight on a plain background
            </div>
            <div
              className="action-row"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload size={16} />
                Upload Leaf Image
              </button>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={openCamera}
              >
                <Camera size={16} />
                Use Camera
              </button>
            </div>
          </div>
        )}

        {cameraError && (
          <div className="warning-banner" role="alert">
            <span>{cameraError}</span>
          </div>
        )}

        <div className="field-group">
          <label className="field-label" htmlFor="plant-select">
            Plant / Crop Species (Optional — boosts accuracy)
          </label>
          <select
            id="plant-select"
            className="select-input"
            value={plantHint}
            onChange={(e) => setPlantHint(e.target.value)}
          >
            {PLANT_SPECIES_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        </div>

        <div className="field-group">
          <span className="field-label">Visible Leaf Clues (Optional)</span>
          <div className="chip-grid">
            {SYMPTOM_CHIPS.map((chip) => {
              const selected = symptomsHint.includes(chip.id);
              return (
                <button
                  key={chip.id}
                  type="button"
                  className={`symptom-chip ${selected ? 'selected' : ''}`}
                  onClick={() => toggleSymptom(chip.id)}
                >
                  {chip.label}
                </button>
              );
            })}
          </div>
        </div>

        <div style={{ marginTop: 20 }}>
          <button
            type="button"
            className="btn btn-emerald"
            style={{ width: '100%', padding: '12px 18px', fontSize: '0.98rem' }}
            disabled={!imageSrc || isAnalyzing}
            onClick={onAnalyze}
          >
            <ScanSearch size={19} />
            {isAnalyzing ? 'Analyzing Leaf Tissue & Symptoms...' : 'Detect Disease & Get Care Plan'}
          </button>
        </div>

        <div className="field-group" style={{ marginTop: 22 }}>
          <span className="field-label">
            <Sparkles size={12} style={{ verticalAlign: 'middle', marginRight: 4 }} />
            Try Instant Demo Specimens
          </span>
          <div className="sample-grid">
            {samples.map((s) => (
              <button
                key={s.id}
                type="button"
                className="sample-card"
                onClick={() => onSelectSample(s)}
              >
                <img className="sample-thumb" src={s.imageUrl} alt={s.label} />
                <span className="sample-name">{s.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
