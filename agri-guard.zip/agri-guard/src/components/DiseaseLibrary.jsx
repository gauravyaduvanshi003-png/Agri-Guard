import { useState } from 'react';
import { Search, BookOpen } from 'lucide-react';
import { DISEASE_DATABASE } from '../data/diseases.js';

export default function DiseaseLibrary() {
  const [query, setQuery] = useState('');
  const [pathogenFilter, setPathogenFilter] = useState('All');

  const pathogens = ['All', 'Fungal', 'Bacterial', 'Oomycete', 'Viral', 'Nutrient / Abiotic', 'Healthy'];

  const filtered = DISEASE_DATABASE.filter((item) => {
    const matchesPathogen =
      pathogenFilter === 'All' || item.pathogenType === pathogenFilter;
    const q = query.trim().toLowerCase();
    const matchesQuery =
      !q ||
      item.plantCommonName.toLowerCase().includes(q) ||
      item.diseaseName.toLowerCase().includes(q) ||
      item.summary.toLowerCase().includes(q);
    return matchesPathogen && matchesQuery;
  });

  return (
    <div>
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">
            <BookOpen size={19} />
            Plant Disease &amp; Care Encyclopedia ({filtered.length})
          </h2>
        </div>
        <div className="card-body">
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
            <div style={{ position: 'relative', flex: '1 1 260px' }}>
              <Search
                size={16}
                style={{
                  position: 'absolute',
                  left: 12,
                  top: '50%',
                  transform: 'translateY(-50%)',
                  color: 'var(--text-muted)',
                }}
              />
              <input
                type="text"
                className="text-input"
                style={{ paddingLeft: 36 }}
                placeholder="Search by plant (Tomato, Rose, Rice...) or disease..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>

            <div className="chip-grid">
              {pathogens.map((p) => (
                <button
                  key={p}
                  type="button"
                  className={`symptom-chip ${pathogenFilter === p ? 'selected' : ''}`}
                  onClick={() => setPathogenFilter(p)}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          <div className="library-grid">
            {filtered.map((item) => (
              <article key={item.id} className="advice-card">
                <div className="badge-row" style={{ marginBottom: 8 }}>
                  <span
                    className={`badge ${
                      item.isHealthy
                        ? 'badge-healthy'
                        : item.severity === 'Critical' || item.severity === 'High'
                        ? 'badge-danger'
                        : 'badge-warning'
                    }`}
                  >
                    {item.isHealthy ? 'Healthy' : item.severity}
                  </span>
                  <span className="badge badge-neutral">{item.pathogenType}</span>
                </div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: 600 }}>
                  {item.plantCommonName} ({item.plantScientificName})
                </div>
                <h3 style={{ margin: '4px 0 8px', fontSize: '1.08rem', color: 'var(--forest)' }}>
                  {item.diseaseName}
                </h3>
                <p style={{ margin: '0 0 10px', fontSize: '0.86rem', color: 'var(--text)' }}>
                  {item.summary}
                </p>
                <div style={{ fontSize: '0.82rem', color: 'var(--forest)', fontWeight: 700 }}>
                  Key Action:
                </div>
                <p style={{ margin: '3px 0 0', fontSize: '0.83rem', color: 'var(--text-muted)' }}>
                  {item.howToSolve.immediateActions[0]}
                </p>
              </article>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
