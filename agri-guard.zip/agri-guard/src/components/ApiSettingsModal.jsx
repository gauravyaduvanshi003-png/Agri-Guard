import { useState } from 'react';
import { X, KeyRound, CheckCircle2, Info } from 'lucide-react';

export default function ApiSettingsModal({
  open,
  onClose,
  apiKey,
  model,
  serverConfigured,
  onSave,
}) {
  const [draftKey, setDraftKey] = useState(apiKey || '');
  const [draftModel, setDraftModel] = useState(model || 'auto');

  if (!open) return null;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <div className="card-header">
          <h2 className="card-title">
            <KeyRound size={18} />
            AI Vision &amp; Accuracy Settings
          </h2>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            <X size={18} />
          </button>
        </div>

        <div className="card-body">
          <div className="info-banner" style={{ marginTop: 0 }}>
            <Info size={18} style={{ flexShrink: 0, marginTop: 2 }} />
            <div>
              <strong>Two-Tier Diagnosis Architecture:</strong>
              <ul className="advice-list" style={{ marginTop: 6 }}>
                <li>
                  <strong>Gemini Vision AI (Recommended):</strong> Identifies thousands of plant
                  species &amp; diseases directly from real-world leaf photographs with high
                  multimodal accuracy.
                </li>
                <li>
                  <strong>Local Optical Screening (Always Built-In):</strong> Runs offline using
                  pixel chlorophyll, chlorosis, necrosis, rust, and powdery-mildew analysis.
                </li>
              </ul>
            </div>
          </div>

          {serverConfigured && (
            <div
              className="info-banner"
              style={{ background: 'var(--emerald-soft)', borderColor: '#9ae6b4' }}
            >
              <CheckCircle2 size={17} style={{ flexShrink: 0 }} />
              <span>
                Server environment <code>GEMINI_API_KEY</code> is already configured in{' '}
                <code>.env</code>. You can still override it below if needed.
              </span>
            </div>
          )}

          <div className="field-group">
            <label className="field-label" htmlFor="gemini-key-input">
              Google Gemini API Key (Optional in browser)
            </label>
            <input
              id="gemini-key-input"
              type="password"
              className="text-input"
              placeholder="AIza..."
              value={draftKey}
              onChange={(e) => setDraftKey(e.target.value)}
            />
            <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: 5 }}>
              Stored locally in your browser and proxied through your local Agri Guard server.
            </div>
          </div>

          <div className="field-group">
            <label className="field-label" htmlFor="gemini-model-select">
              Vision Model
            </label>
            <select
              id="gemini-model-select"
              className="select-input"
              value={draftModel}
              onChange={(e) => setDraftModel(e.target.value)}
            >
              <option value="auto">Auto (Best Available Gemini Vision Model — Recommended)</option>
              <option value="gemini-2.5-flash">gemini-2.5-flash (Fast &amp; High Accuracy)</option>
              <option value="gemini-2.0-flash">gemini-2.0-flash (Broadly Available Flash)</option>
              <option value="gemini-2.5-pro">gemini-2.5-pro (Deepest Botanical Reasoning)</option>
            </select>
          </div>

          <div className="action-row" style={{ justifyContent: 'flex-end', marginTop: 20 }}>
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button
              type="button"
              className="btn btn-emerald"
              onClick={() => {
                onSave(draftKey.trim(), draftModel);
                onClose();
              }}
            >
              Save Settings
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
