import { useState } from 'react';
import {
  CheckCircle2,
  AlertTriangle,
  Stethoscope,
  Droplets,
  Sun,
  Sprout,
  ShieldAlert,
  Printer,
  Info,
  Microscope,
  Sparkles,
} from 'lucide-react';

export default function DiagnosisReport({
  result,
  imageSrc,
  pixelMetrics,
  engineUsed,
  cloudReady,
  isAnalyzing,
  onReanalyze,
  onOpenSettings,
}) {
  const [viewMode, setViewMode] = useState('original');

  if (!result) {
    return (
      <section className="card">
        <div className="card-header">
          <h2 className="card-title">
            <Stethoscope size={19} />
            2. Disease Diagnosis &amp; Plant Care Report
          </h2>
        </div>
        <div className="empty-state">
          <Microscope size={44} style={{ color: 'var(--forest)', opacity: 0.7, marginBottom: 12 }} />
          <h3 style={{ margin: '0 0 8px', color: 'var(--forest)' }}>
            Ready to Inspect Your Plant Leaf
          </h3>
          <p style={{ maxWidth: 460, margin: '0 auto 18px', fontSize: '0.94rem' }}>
            Upload or snap a leaf photo on the left—or click any demo specimen—to detect the{' '}
            <strong>plant leaf name</strong>, <strong>disease name</strong>,{' '}
            <strong>step-by-step treatment</strong>, and <strong>healthy care plan</strong>.
          </p>
          <div className="info-banner" style={{ textAlign: 'left', maxWidth: 520, margin: '0 auto' }}>
            <Info size={18} style={{ flexShrink: 0, marginTop: 2 }} />
            <div>
              <strong>How Agri Guard maximizes accuracy:</strong> Every photo goes through an
              optical focus &amp; leaf-tissue gate first. For highest real-world recognition across
              thousands of species, connect a free Google Gemini Vision API key in{' '}
              <button
                type="button"
                onClick={onOpenSettings}
                style={{
                  border: 'none',
                  background: 'none',
                  color: 'var(--forest)',
                  fontWeight: 700,
                  textDecoration: 'underline',
                  cursor: 'pointer',
                  padding: 0,
                }}
              >
                API Settings
              </button>
              . No real-world vision model can guarantee 100% accuracy on every photo, so we always
              display calibrated confidence and look-alike notes.
            </div>
          </div>
        </div>
      </section>
    );
  }

  const severityBadgeClass = result.isHealthy
    ? 'badge-healthy'
    : result.severity === 'Critical' || result.severity === 'High'
    ? 'badge-danger'
    : 'badge-warning';

  const confColor =
    result.confidence >= 85
      ? 'var(--emerald)'
      : result.confidence >= 65
      ? '#d97706'
      : 'var(--crimson)';

  return (
    <section className="card">
      <div className="card-header">
        <h2 className="card-title">
          <Stethoscope size={19} />
          2. Diagnosis &amp; Agronomic Recovery Report
        </h2>
        <button
          type="button"
          className="btn btn-secondary no-print"
          onClick={() => window.print()}
        >
          <Printer size={15} />
          Print / Save PDF
        </button>
      </div>

      <div className="card-body">
        <div className="report-hero">
          <div>
            <div className="visual-inspect-card">
              <img
                src={
                  viewMode === 'overlay' && pixelMetrics?.overlayDataUrl
                    ? pixelMetrics.overlayDataUrl
                    : imageSrc
                }
                alt={viewMode === 'overlay' ? 'Optical lesion overlay' : 'Uploaded leaf'}
              />
              {pixelMetrics?.overlayDataUrl && (
                <div className="visual-toggle no-print">
                  <button
                    type="button"
                    className={viewMode === 'original' ? 'active' : ''}
                    onClick={() => setViewMode('original')}
                  >
                    Original Photo
                  </button>
                  <button
                    type="button"
                    className={viewMode === 'overlay' ? 'active' : ''}
                    onClick={() => setViewMode('overlay')}
                  >
                    Lesion Heatmap
                  </button>
                </div>
              )}
            </div>

            {pixelMetrics?.overlayDataUrl && viewMode === 'overlay' && (
              <div className="legend-row">
                <span className="legend-item">
                  <span className="legend-swatch" style={{ background: '#10b981' }} /> Healthy
                </span>
                <span className="legend-item">
                  <span className="legend-swatch" style={{ background: '#f59e0b' }} /> Chlorosis
                </span>
                <span className="legend-item">
                  <span className="legend-swatch" style={{ background: '#e11d48' }} /> Necrosis
                </span>
                <span className="legend-item">
                  <span className="legend-swatch" style={{ background: '#f97316' }} /> Rust
                </span>
                <span className="legend-item">
                  <span className="legend-swatch" style={{ background: '#38bdf8' }} /> Powdery
                </span>
              </div>
            )}
          </div>

          <div>
            <div className="badge-row">
              <span className={`badge ${severityBadgeClass}`}>
                {result.isHealthy ? <CheckCircle2 size={14} /> : <AlertTriangle size={14} />}
                {result.isHealthy ? 'Healthy Foliage' : `Severity: ${result.severity}`}
              </span>
              <span className="badge badge-neutral">{result.pathogenType}</span>
              <span className="badge badge-sky">
                <Sparkles size={12} />
                {engineUsed === 'gemini-vision' ? 'Gemini Vision AI' : 'Local Optical Screening'}
              </span>
            </div>

            {engineUsed !== 'gemini-vision' && cloudReady && (
              <div
                className="info-banner no-print"
                style={{ marginTop: 0, marginBottom: 12, flexWrap: 'wrap', alignItems: 'center' }}
              >
                <Sparkles size={17} style={{ flexShrink: 0 }} />
                <div style={{ flex: '1 1 180px', minWidth: 0 }}>
                  <strong>Gemini Vision AI is now ready!</strong> This report was created in Local
                  Optical Mode. Re-scan to get full AI species &amp; disease recognition.
                </div>
                <button
                  type="button"
                  className="btn btn-emerald"
                  style={{ padding: '6px 12px', fontSize: '0.8rem', whiteSpace: 'nowrap' }}
                  disabled={isAnalyzing}
                  onClick={onReanalyze}
                >
                  {isAnalyzing ? 'Scanning...' : 'Re-Analyze with AI'}
                </button>
              </div>
            )}

            <p className="diagnosis-plant">
              <strong>Leaf / Plant Name:</strong> {result.plantCommonName}{' '}
              {result.plantScientificName && result.plantScientificName !== '—' && (
                <em>({result.plantScientificName})</em>
              )}
            </p>
            <h3 className="diagnosis-title">{result.diseaseName}</h3>
            <p style={{ margin: '0 0 10px', fontSize: '0.93rem', color: 'var(--text)' }}>
              {result.summary}
            </p>

            {result.isLeaf ? (
              <div className="confidence-wrap">
                <div className="confidence-top">
                  <span>Diagnostic Confidence</span>
                  <span className="font-mono">{result.confidence}%</span>
                </div>
                <div className="confidence-bar">
                  <div
                    className="confidence-fill"
                    style={{ width: `${result.confidence}%`, background: confColor }}
                  />
                </div>
              </div>
            ) : (
              <div className="warning-banner">
                <ShieldAlert size={18} style={{ flexShrink: 0 }} />
                <div>{result.rejectionReason}</div>
              </div>
            )}
          </div>
        </div>

        {pixelMetrics && (
          <div className="metrics-grid">
            <div className="metric-box">
              <div className="metric-label">Healthy Green</div>
              <div className="metric-val font-mono">{pixelMetrics.healthyGreenPct}%</div>
            </div>
            <div className="metric-box">
              <div className="metric-label">Yellowing (Chlorosis)</div>
              <div className="metric-val font-mono">{pixelMetrics.chlorosisPct}%</div>
            </div>
            <div className="metric-box">
              <div className="metric-label">Dark Spots (Necrosis)</div>
              <div className="metric-val font-mono">{pixelMetrics.necrosisPct}%</div>
            </div>
            <div className="metric-box">
              <div className="metric-label">Rust / Powdery</div>
              <div className="metric-val font-mono">
                {Math.round((pixelMetrics.rustOrangePct + pixelMetrics.powderyWhitePct) * 10) / 10}%
              </div>
            </div>
            <div className="metric-box">
              <div className="metric-label">Photo Focus Score</div>
              <div className="metric-val font-mono">{pixelMetrics.sharpnessScore}/100</div>
            </div>
          </div>
        )}

        {result.observedSymptoms?.length > 0 && (
          <div className="section-block">
            <h4 className="section-heading">Observed Symptoms &amp; Tissue Evidence</h4>
            <ul className="advice-list">
              {result.observedSymptoms.map((sym, i) => (
                <li key={i}>{sym}</li>
              ))}
            </ul>
          </div>
        )}

        {result.isLeaf && (
          <>
            <div className="section-block">
              <h4 className="section-heading">
                <ShieldAlert size={18} />
                How to Solve This Disease
              </h4>
              <div className="advice-columns">
                <div className="advice-card">
                  <h4>1. Immediate Actions</h4>
                  <ul className="advice-list">
                    {result.howToSolve?.immediateActions?.map((item, idx) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                </div>
                <div className="advice-card">
                  <h4>2. Organic &amp; Home Remedies</h4>
                  <ul className="advice-list">
                    {result.howToSolve?.organicRemedies?.map((item, idx) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                </div>
                <div className="advice-card">
                  <h4>3. Targeted Treatments</h4>
                  <ul className="advice-list">
                    {result.howToSolve?.targetedTreatments?.map((item, idx) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>
              {result.howToSolve?.recoveryTimeline && (
                <div className="info-banner">
                  <Info size={17} style={{ flexShrink: 0, marginTop: 2 }} />
                  <div>
                    <strong>Recovery Timeline:</strong> {result.howToSolve.recoveryTimeline}
                  </div>
                </div>
              )}
            </div>

            <div className="section-block">
              <h4 className="section-heading">
                <Sprout size={18} />
                More Advice to Keep Your Plant Healthy
              </h4>
              <div className="advice-columns">
                <div className="advice-card">
                  <h4>
                    <Droplets size={15} /> Watering Protocol
                  </h4>
                  <p style={{ margin: 0, fontSize: '0.87rem' }}>
                    {result.healthyCareAdvice?.watering}
                  </p>
                </div>
                <div className="advice-card">
                  <h4>
                    <Sun size={15} /> Sunlight &amp; Airflow
                  </h4>
                  <p style={{ margin: 0, fontSize: '0.87rem' }}>
                    {result.healthyCareAdvice?.sunlightAndAirflow}
                  </p>
                </div>
                <div className="advice-card">
                  <h4>
                    <Sprout size={15} /> Soil &amp; Nutrition
                  </h4>
                  <p style={{ margin: 0, fontSize: '0.87rem' }}>
                    {result.healthyCareAdvice?.soilAndNutrition}
                  </p>
                </div>
              </div>

              {result.healthyCareAdvice?.preventiveChecklist?.length > 0 && (
                <div className="advice-card" style={{ marginTop: 14 }}>
                  <h4>Preventive Care Checklist</h4>
                  <ul className="advice-list">
                    {result.healthyCareAdvice.preventiveChecklist.map((tip, idx) => (
                      <li key={idx}>{tip}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </>
        )}

        {result.accuracyNotes && (
          <div className="warning-banner">
            <Info size={17} style={{ flexShrink: 0, marginTop: 2 }} />
            <div>
              <strong>Accuracy &amp; Differential Note:</strong> {result.accuracyNotes}
              {result.alternatives?.length > 0 && (
                <div style={{ marginTop: 4 }}>
                  Look-alike possibilities:{' '}
                  {result.alternatives
                    .map((a) => `${a.diseaseName} (${a.plantCommonName})`)
                    .join(' • ')}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
