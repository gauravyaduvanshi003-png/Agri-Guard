import { useEffect, useMemo, useState } from 'react';
import { Trash2, Clock, ArrowRight } from 'lucide-react';
import Navbar from './components/Navbar.jsx';
import UploadScanner from './components/UploadScanner.jsx';
import DiagnosisReport from './components/DiagnosisReport.jsx';
import DiseaseLibrary from './components/DiseaseLibrary.jsx';
import ApiSettingsModal from './components/ApiSettingsModal.jsx';
import { analyzeLeafImagePixels, runLocalDiagnosis } from './utils/leafAnalyzer.js';
import { generateSampleLeaves } from './utils/sampleLeaves.js';

const HISTORY_KEY = 'agri_guard_history_v1';
const SETTINGS_KEY = 'agri_guard_settings_v1';

export default function App() {
  const [activeTab, setActiveTab] = useState('scanner');
  const [imageSrc, setImageSrc] = useState('');
  const [imageMime, setImageMime] = useState('image/jpeg');
  const [plantHint, setPlantHint] = useState('auto');
  const [symptomsHint, setSymptomsHint] = useState([]);
  const [pixelMetrics, setPixelMetrics] = useState(null);
  const [result, setResult] = useState(null);
  const [engineUsed, setEngineUsed] = useState('local-optical');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [errorBanner, setErrorBanner] = useState('');
  const [settingsOpen, setSettingsOpen] = useState(false);

  const [serverConfigured, setServerConfigured] = useState(false);
  const [clientApiKey, setClientApiKey] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}');
      return saved.apiKey || '';
    } catch {
      return '';
    }
  });
  const [geminiModel, setGeminiModel] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}');
      return saved.model || 'auto';
    } catch {
      return 'auto';
    }
  });

  const [history, setHistory] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
    } catch {
      return [];
    }
  });

  const samples = useMemo(() => generateSampleLeaves(), []);

  useEffect(() => {
    fetch('/api/health')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data?.serverGeminiConfigured) setServerConfigured(true);
      })
      .catch(() => {
        // Offline / Vite-only mode still works via Local Optical Screening
      });
  }, []);

  function saveHistory(next) {
    setHistory(next);
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(next.slice(0, 15)));
    } catch {
      // Ignore quota errors on large base64 thumbnails
    }
  }

  function handleSaveSettings(key, model) {
    setClientApiKey(key);
    setGeminiModel(model);
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify({ apiKey: key, model }));
    } catch {
      // ignore
    }
    if (imageSrc && (key || serverConfigured)) {
      setTimeout(() => {
        runAnalysis(key, model);
      }, 0);
    }
  }

  function handleSelectImage(dataUrl, mime) {
    setImageSrc(dataUrl);
    setImageMime(mime || 'image/jpeg');
    setResult(null);
    setPixelMetrics(null);
    setErrorBanner('');
  }

  function handleSelectSample(sample) {
    setImageSrc(sample.imageUrl);
    setImageMime('image/png');
    setPlantHint(sample.plantHint);
    setSymptomsHint(sample.symptoms);
    setResult(null);
    setPixelMetrics(null);
    setErrorBanner('');
  }

  function handleClear() {
    setImageSrc('');
    setPlantHint('auto');
    setSymptomsHint([]);
    setPixelMetrics(null);
    setResult(null);
    setErrorBanner('');
  }

  async function handleAnalyze() {
    await runAnalysis(clientApiKey, geminiModel);
  }

  async function runAnalysis(activeKey = clientApiKey, activeModel = geminiModel) {
    if (!imageSrc) return;
    setIsAnalyzing(true);
    setErrorBanner('');

    try {
      // 1. Always compute real pixel-level optical telemetry & lesion heatmap
      const metrics = await analyzeLeafImagePixels(imageSrc);
      setPixelMetrics(metrics);

      const cloudAvailable = Boolean(activeKey || serverConfigured);
      let finalDiagnosis = null;
      let usedEngine = 'local-optical';

      // 2. Use Gemini Vision API if configured (server or browser key)
      if (cloudAvailable) {
        try {
          const resp = await fetch('/api/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              imageBase64: imageSrc,
              mimeType: imageMime,
              plantHint,
              symptomsHint,
              pixelMetrics: {
                healthyGreenPct: metrics.healthyGreenPct,
                chlorosisPct: metrics.chlorosisPct,
                necrosisPct: metrics.necrosisPct,
                rustOrangePct: metrics.rustOrangePct,
                powderyWhitePct: metrics.powderyWhitePct,
                sharpnessScore: metrics.sharpnessScore,
              },
              clientApiKey: activeKey,
              model: activeModel,
            }),
          });

          if (resp.ok) {
            const payload = await resp.json();
            if (payload?.diagnosis) {
              finalDiagnosis = payload.diagnosis;
              usedEngine = 'gemini-vision';
            }
          } else {
            const errJson = await resp.json().catch(() => ({}));
            if (errJson?.code !== 'NO_API_KEY') {
              const detailText = errJson?.details ? ` — ${errJson.details}` : '';
              setErrorBanner(
                `Cloud Vision fell back to Local Optical Mode: ${errJson?.error || resp.statusText}${detailText}`
              );
            }
          }
        } catch (netErr) {
          setErrorBanner(
            `API server unreachable (${netErr.message}); used Local Optical Screening instead.`
          );
        }
      }

      // 3. Fallback or default Local Optical Screening
      if (!finalDiagnosis) {
        finalDiagnosis = runLocalDiagnosis(metrics, plantHint, symptomsHint);
        usedEngine = 'local-optical';
      }

      setResult(finalDiagnosis);
      setEngineUsed(usedEngine);

      if (finalDiagnosis.isLeaf) {
        const entry = {
          id: `${Date.now()}`,
          timestamp: new Date().toISOString(),
          plantCommonName: finalDiagnosis.plantCommonName,
          diseaseName: finalDiagnosis.diseaseName,
          isHealthy: finalDiagnosis.isHealthy,
          severity: finalDiagnosis.severity,
          confidence: finalDiagnosis.confidence,
          engineUsed: usedEngine,
          imageSrc,
          metrics,
          result: finalDiagnosis,
        };
        saveHistory([entry, ...history].slice(0, 15));
      }
    } catch (err) {
      setErrorBanner(err?.message || 'Unable to analyze this image.');
    } finally {
      setIsAnalyzing(false);
    }
  }

  const cloudReady = Boolean(clientApiKey || serverConfigured);

  return (
    <div className="app-shell">
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cloudReady={cloudReady}
        historyCount={history.length}
        onOpenSettings={() => setSettingsOpen(true)}
      />

      <main className="main-content">
        {activeTab === 'scanner' && (
          <>
            <div className="hero-strip">
              <div>
                <h2 className="hero-title">Instant Plant Leaf Disease Diagnosis &amp; Care</h2>
                <p className="hero-desc">
                  Take or upload a photo of any plant leaf. Agri Guard inspects leaf tissue,
                  identifies the <strong>plant name</strong> and <strong>disease</strong>, provides{' '}
                  <strong>organic &amp; targeted remedies</strong>, and gives tailored advice to keep
                  your plant healthy.
                </p>
              </div>
            </div>

            {errorBanner && (
              <div className="warning-banner" style={{ marginBottom: 18 }}>
                <span>{errorBanner}</span>
              </div>
            )}

            <div className="workspace-grid">
              <UploadScanner
                imageSrc={imageSrc}
                onSelectImage={handleSelectImage}
                plantHint={plantHint}
                setPlantHint={setPlantHint}
                symptomsHint={symptomsHint}
                setSymptomsHint={setSymptomsHint}
                onAnalyze={handleAnalyze}
                isAnalyzing={isAnalyzing}
                samples={samples}
                onSelectSample={handleSelectSample}
                onClear={handleClear}
              />

              <DiagnosisReport
                result={result}
                imageSrc={imageSrc}
                pixelMetrics={pixelMetrics}
                engineUsed={engineUsed}
                cloudReady={cloudReady}
                isAnalyzing={isAnalyzing}
                onReanalyze={handleAnalyze}
                onOpenSettings={() => setSettingsOpen(true)}
              />
            </div>
          </>
        )}

        {activeTab === 'library' && <DiseaseLibrary />}

        {activeTab === 'history' && (
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">
                <Clock size={19} />
                Recent Leaf Scans ({history.length})
              </h2>
              {history.length > 0 && (
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => saveHistory([])}
                >
                  <Trash2 size={15} />
                  Clear History
                </button>
              )}
            </div>
            <div className="card-body">
              {history.length === 0 ? (
                <div className="empty-state">
                  <p>No saved scans yet. Analyze a leaf in the Leaf Scanner tab to build your plant health log.</p>
                </div>
              ) : (
                <div className="library-grid">
                  {history.map((item) => (
                    <div key={item.id} className="advice-card">
                      <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                        <img
                          src={item.imageSrc}
                          alt={item.plantCommonName}
                          style={{
                            width: 64,
                            height: 64,
                            borderRadius: 10,
                            objectFit: 'cover',
                            border: '1px solid var(--border)',
                          }}
                        />
                        <div style={{ minWidth: 0, flex: 1 }}>
                          <div style={{ fontSize: '0.76rem', color: 'var(--text-muted)' }}>
                            {new Date(item.timestamp).toLocaleString()}
                          </div>
                          <div style={{ fontWeight: 700, color: 'var(--forest)' }}>
                            {item.plantCommonName}
                          </div>
                          <div style={{ fontSize: '0.86rem' }}>{item.diseaseName}</div>
                        </div>
                      </div>
                      <div
                        style={{
                          display: 'flex',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          marginTop: 12,
                        }}
                      >
                        <span
                          className={`badge ${
                            item.isHealthy ? 'badge-healthy' : 'badge-warning'
                          }`}
                        >
                          {item.confidence}% confidence
                        </span>
                        <button
                          type="button"
                          className="btn btn-secondary"
                          style={{ padding: '6px 12px', fontSize: '0.8rem' }}
                          onClick={() => {
                            setImageSrc(item.imageSrc);
                            setPixelMetrics(item.metrics);
                            setResult(item.result);
                            setEngineUsed(item.engineUsed);
                            setActiveTab('scanner');
                          }}
                        >
                          Open Report <ArrowRight size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      <ApiSettingsModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        apiKey={clientApiKey}
        model={geminiModel}
        serverConfigured={serverConfigured}
        onSave={handleSaveSettings}
      />
    </div>
  );
}
