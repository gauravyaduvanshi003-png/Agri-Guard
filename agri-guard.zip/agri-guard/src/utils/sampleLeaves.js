function drawBaseLeaf(ctx, w, h, baseColor, veinColor) {
  ctx.fillStyle = '#f5f2ea';
  ctx.fillRect(0, 0, w, h);

  // Subtle lab grid
  ctx.strokeStyle = 'rgba(20, 45, 30, 0.05)';
  ctx.lineWidth = 1;
  for (let x = 0; x < w; x += 24) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
    ctx.stroke();
  }
  for (let y = 0; y < h; y += 24) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }

  // Stem
  ctx.strokeStyle = '#3f6e33';
  ctx.lineWidth = 8;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(w * 0.5, h * 0.92);
  ctx.quadraticCurveTo(w * 0.5, h * 0.82, w * 0.5, h * 0.74);
  ctx.stroke();

  // Leaf silhouette
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(w * 0.5, h * 0.12);
  ctx.bezierCurveTo(w * 0.85, h * 0.28, w * 0.88, h * 0.66, w * 0.5, h * 0.78);
  ctx.bezierCurveTo(w * 0.12, h * 0.66, w * 0.15, h * 0.28, w * 0.5, h * 0.12);
  ctx.closePath();

  const grad = ctx.createLinearGradient(w * 0.25, h * 0.15, w * 0.75, h * 0.75);
  grad.addColorStop(0, baseColor[0]);
  grad.addColorStop(0.5, baseColor[1]);
  grad.addColorStop(1, baseColor[2]);
  ctx.fillStyle = grad;
  ctx.fill();
  ctx.clip();

  // Midrib & lateral veins
  ctx.strokeStyle = veinColor;
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(w * 0.5, h * 0.78);
  ctx.lineTo(w * 0.5, h * 0.16);
  ctx.stroke();

  ctx.lineWidth = 2;
  const veinYs = [0.66, 0.56, 0.46, 0.36, 0.26];
  veinYs.forEach((vy, i) => {
    const spread = 0.22 - i * 0.025;
    ctx.beginPath();
    ctx.moveTo(w * 0.5, h * vy);
    ctx.quadraticCurveTo(w * (0.5 - spread * 0.6), h * (vy - 0.04), w * (0.5 - spread), h * (vy - 0.09));
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(w * 0.5, h * vy);
    ctx.quadraticCurveTo(w * (0.5 + spread * 0.6), h * (vy - 0.04), w * (0.5 + spread), h * (vy - 0.09));
    ctx.stroke();
  });

  return () => ctx.restore();
}

export function generateSampleLeaves() {
  const w = 360;
  const h = 360;

  // 1. Healthy Tomato Leaf
  const c1 = document.createElement('canvas');
  c1.width = w;
  c1.height = h;
  const ctx1 = c1.getContext('2d');
  const end1 = drawBaseLeaf(ctx1, w, h, ['#3a8c40', '#2d7a36', '#215f2a'], 'rgba(165, 224, 150, 0.55)');
  end1();

  // 2. Tomato Early Blight
  const c2 = document.createElement('canvas');
  c2.width = w;
  c2.height = h;
  const ctx2 = c2.getContext('2d');
  const end2 = drawBaseLeaf(ctx2, w, h, ['#49873d', '#3a7432', '#2f5f28'], 'rgba(170, 210, 140, 0.45)');
  const blightSpots = [
    [0.37, 0.45, 26],
    [0.61, 0.54, 29],
    [0.44, 0.62, 22],
    [0.57, 0.36, 18],
    [0.32, 0.58, 17],
  ];
  blightSpots.forEach(([sx, sy, r]) => {
    const cx = w * sx;
    const cy = h * sy;
    const halo = ctx2.createRadialGradient(cx, cy, r * 0.4, cx, cy, r * 1.45);
    halo.addColorStop(0, 'rgba(218, 179, 32, 0.85)');
    halo.addColorStop(1, 'rgba(218, 179, 32, 0)');
    ctx2.fillStyle = halo;
    ctx2.beginPath();
    ctx2.arc(cx, cy, r * 1.45, 0, Math.PI * 2);
    ctx2.fill();

    ctx2.fillStyle = '#3b2416';
    ctx2.beginPath();
    ctx2.arc(cx, cy, r * 0.72, 0, Math.PI * 2);
    ctx2.fill();

    ctx2.strokeStyle = '#6e4726';
    ctx2.lineWidth = 2;
    ctx2.beginPath();
    ctx2.arc(cx, cy, r * 0.45, 0, Math.PI * 2);
    ctx2.stroke();
  });
  end2();

  // 3. Powdery Mildew
  const c3 = document.createElement('canvas');
  c3.width = w;
  c3.height = h;
  const ctx3 = c3.getContext('2d');
  const end3 = drawBaseLeaf(ctx3, w, h, ['#3a803c', '#2e6b31', '#265828'], 'rgba(175, 215, 165, 0.45)');
  const powderPatches = [
    [0.42, 0.36, 36],
    [0.58, 0.44, 42],
    [0.36, 0.54, 34],
    [0.53, 0.60, 32],
    [0.48, 0.25, 25],
  ];
  powderPatches.forEach(([px, py, r]) => {
    const cx = w * px;
    const cy = h * py;
    const g = ctx3.createRadialGradient(cx, cy, 4, cx, cy, r);
    g.addColorStop(0, 'rgba(248, 250, 249, 0.94)');
    g.addColorStop(0.55, 'rgba(235, 242, 238, 0.75)');
    g.addColorStop(1, 'rgba(235, 242, 238, 0)');
    ctx3.fillStyle = g;
    ctx3.beginPath();
    ctx3.arc(cx, cy, r, 0, Math.PI * 2);
    ctx3.fill();
  });
  end3();

  // 4. Apple / Corn Rust
  const c4 = document.createElement('canvas');
  c4.width = w;
  c4.height = h;
  const ctx4 = c4.getContext('2d');
  const end4 = drawBaseLeaf(ctx4, w, h, ['#4b8b3b', '#3b7931', '#2c6026'], 'rgba(175, 215, 140, 0.45)');
  const rustSpots = [
    [0.36, 0.35, 14],
    [0.59, 0.38, 16],
    [0.44, 0.48, 15],
    [0.62, 0.56, 17],
    [0.34, 0.56, 13],
    [0.50, 0.64, 15],
    [0.48, 0.29, 12],
  ];
  rustSpots.forEach(([rx, ry, r]) => {
    const cx = w * rx;
    const cy = h * ry;
    const halo = ctx4.createRadialGradient(cx, cy, 3, cx, cy, r * 1.5);
    halo.addColorStop(0, 'rgba(234, 179, 8, 0.78)');
    halo.addColorStop(1, 'rgba(234, 179, 8, 0)');
    ctx4.fillStyle = halo;
    ctx4.beginPath();
    ctx4.arc(cx, cy, r * 1.5, 0, Math.PI * 2);
    ctx4.fill();

    ctx4.fillStyle = '#d95b16';
    ctx4.beginPath();
    ctx4.arc(cx, cy, r * 0.65, 0, Math.PI * 2);
    ctx4.fill();

    ctx4.fillStyle = '#8f2d08';
    ctx4.beginPath();
    ctx4.arc(cx, cy, r * 0.28, 0, Math.PI * 2);
    ctx4.fill();
  });
  end4();

  return [
    {
      id: 'sample-healthy',
      label: 'Healthy Tomato Leaf',
      plantHint: 'Tomato',
      symptoms: ['healthy_green'],
      imageUrl: c1.toDataURL('image/png'),
    },
    {
      id: 'sample-early-blight',
      label: 'Tomato Early Blight',
      plantHint: 'Tomato',
      symptoms: ['concentric_rings', 'yellow_halo'],
      imageUrl: c2.toDataURL('image/png'),
    },
    {
      id: 'sample-powdery-mildew',
      label: 'Powdery Mildew Leaf',
      plantHint: 'Rose',
      symptoms: ['white_powder'],
      imageUrl: c3.toDataURL('image/png'),
    },
    {
      id: 'sample-rust',
      label: 'Cedar Apple Rust',
      plantHint: 'Apple',
      symptoms: ['orange_pustules', 'yellow_halo'],
      imageUrl: c4.toDataURL('image/png'),
    },
  ];
}
