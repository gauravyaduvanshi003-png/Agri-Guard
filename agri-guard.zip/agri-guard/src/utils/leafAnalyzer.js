import { DISEASE_DATABASE, PLANT_SPECIES_OPTIONS } from '../data/diseases.js';

function rgbToHsv(r, g, b) {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const d = max - min;

  let h = 0;
  if (d !== 0) {
    if (max === rn) h = ((gn - bn) / d) % 6;
    else if (max === gn) h = (bn - rn) / d + 2;
    else h = (rn - gn) / d + 4;
    h *= 60;
    if (h < 0) h += 360;
  }

  const s = max === 0 ? 0 : d / max;
  const v = max;
  return { h, s, v };
}

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to decode image file.'));
    img.src = src;
  });
}

function rangeFitScore(val, [min, max]) {
  if (val >= min && val <= max) return 1.0;
  const span = Math.max(8, max - min);
  const dist = val < min ? min - val : val - max;
  return Math.max(0, 1 - dist / (span * 1.35));
}

export async function analyzeLeafImagePixels(imageSrc) {
  const img = await loadImage(imageSrc);
  const maxDim = 224;
  const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
  const width = Math.max(48, Math.round(img.width * scale));
  const height = Math.max(48, Math.round(img.height * scale));

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(img, 0, 0, width, height);

  const imageData = ctx.getImageData(0, 0, width, height);
  const { data } = imageData;

  const overlayCanvas = document.createElement('canvas');
  overlayCanvas.width = width;
  overlayCanvas.height = height;
  const octx = overlayCanvas.getContext('2d');
  const overlayImg = octx.createImageData(width, height);
  const odata = overlayImg.data;

  const totalPixels = width * height;
  const gray = new Float32Array(totalPixels);
  const isBackground = new Uint8Array(totalPixels);

  // Sample border pixels to estimate background brightness/neutrality
  let borderBrightSum = 0;
  let borderCount = 0;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = y * width + x;
      const p = idx * 4;
      const r = data[p];
      const g = data[p + 1];
      const b = data[p + 2];
      gray[idx] = 0.299 * r + 0.587 * g + 0.114 * b;

      if (x < 4 || x >= width - 4 || y < 4 || y >= height - 4) {
        borderBrightSum += gray[idx];
        borderCount++;
      }
    }
  }

  const avgBorderBright = borderCount ? borderBrightSum / borderCount : 200;
  const lightBg = avgBorderBright > 155;

  // First pass: segment organic leaf pixels vs uniform studio/outdoor background
  let leafPixelCount = 0;
  const pixelLabels = new Uint8Array(totalPixels); // 0=bg, 1=healthyGreen, 2=chlorosis, 3=necrosis, 4=rust, 5=powdery

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = y * width + x;
      const p = idx * 4;
      const r = data[p];
      const g = data[p + 1];
      const b = data[p + 2];
      const a = data[p + 3];

      if (a < 40) {
        isBackground[idx] = 1;
        continue;
      }

      const { h, s, v } = rgbToHsv(r, g, b);

      // Background heuristic: very low saturation bright white/gray (studio bg) or very dark void
      const isStudioWhite = lightBg && v > 0.78 && s < 0.16 && g - b < 14;
      const isDarkVoid = !lightBg && v < 0.12 && s < 0.22;
      const isBlueSky = h >= 185 && h <= 245 && s > 0.25;

      // Distance from center helps preserve interior powdery white spots inside the leaf
      const nx = (x - width / 2) / (width / 2);
      const ny = (y - height / 2) / (height / 2);
      const centerDist = Math.sqrt(nx * nx + ny * ny);

      if ((isStudioWhite && centerDist > 0.58) || isDarkVoid || isBlueSky) {
        isBackground[idx] = 1;
        continue;
      }

      // Check organic plant hues
      const isGreen = h >= 68 && h <= 165 && s >= 0.16 && v >= 0.14;
      const isYellow = h >= 38 && h < 68 && s >= 0.22 && v >= 0.28;
      const isRustOrange = h >= 12 && h < 38 && s >= 0.34 && v >= 0.28;
      const isBrownNecrosis =
        ((h >= 0 && h < 42) || h > 330) &&
        v < 0.45 &&
        v >= 0.05 &&
        (s >= 0.14 || r > b + 6);
      const isVeryDarkLesion = v < 0.22 && centerDist < 0.78 && g >= b * 0.85;
      const isPowderyPatch =
        centerDist < 0.72 && v >= 0.66 && s <= 0.22 && !isStudioWhite;

      if (isGreen) {
        pixelLabels[idx] = 1;
        leafPixelCount++;
      } else if (isYellow) {
        pixelLabels[idx] = 2;
        leafPixelCount++;
      } else if (isRustOrange) {
        pixelLabels[idx] = 4;
        leafPixelCount++;
      } else if (isBrownNecrosis || isVeryDarkLesion) {
        pixelLabels[idx] = 3;
        leafPixelCount++;
      } else if (isPowderyPatch) {
        pixelLabels[idx] = 5;
        leafPixelCount++;
      } else {
        isBackground[idx] = 1;
      }
    }
  }

  // Filter powdery false positives if leaf doesn't actually have green/yellow plant tissue around it
  let greenCount = 0;
  let chlorosisCount = 0;
  let necrosisCount = 0;
  let rustCount = 0;
  let powderyCount = 0;
  let edgeBrownCount = 0;
  let brightnessSum = 0;

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = y * width + x;
      const p = idx * 4;
      brightnessSum += gray[idx];

      const label = pixelLabels[idx];
      if (label === 1) greenCount++;
      else if (label === 2) chlorosisCount++;
      else if (label === 3) {
        necrosisCount++;
        // Check if adjacent to background (leaf edge/tip burn)
        const nearBg =
          (x > 2 && isBackground[idx - 3]) ||
          (x < width - 3 && isBackground[idx + 3]) ||
          (y > 2 && isBackground[idx - width * 3]) ||
          (y < height - 3 && isBackground[idx + width * 3]);
        if (nearBg) edgeBrownCount++;
      } else if (label === 4) rustCount++;
      else if (label === 5) powderyCount++;

      // Build diagnostic overlay pixel
      const r = data[p];
      const g = data[p + 1];
      const b = data[p + 2];

      if (label === 1) {
        // Soft emerald highlight
        odata[p] = Math.round(r * 0.72 + 16 * 0.28);
        odata[p + 1] = Math.round(g * 0.72 + 185 * 0.28);
        odata[p + 2] = Math.round(b * 0.72 + 129 * 0.28);
        odata[p + 3] = 255;
      } else if (label === 2) {
        // Amber chlorosis highlight
        odata[p] = Math.round(r * 0.45 + 245 * 0.55);
        odata[p + 1] = Math.round(g * 0.45 + 158 * 0.55);
        odata[p + 2] = Math.round(b * 0.45 + 11 * 0.55);
        odata[p + 3] = 255;
      } else if (label === 3) {
        // Crimson necrosis highlight
        odata[p] = Math.round(r * 0.35 + 225 * 0.65);
        odata[p + 1] = Math.round(g * 0.35 + 29 * 0.65);
        odata[p + 2] = Math.round(b * 0.35 + 72 * 0.65);
        odata[p + 3] = 255;
      } else if (label === 4) {
        // Rust orange highlight
        odata[p] = Math.round(r * 0.35 + 249 * 0.65);
        odata[p + 1] = Math.round(g * 0.35 + 115 * 0.65);
        odata[p + 2] = Math.round(b * 0.35 + 22 * 0.65);
        odata[p + 3] = 255;
      } else if (label === 5) {
        // Cyan powdery mildew highlight
        odata[p] = Math.round(r * 0.4 + 56 * 0.6);
        odata[p + 1] = Math.round(g * 0.4 + 189 * 0.6);
        odata[p + 2] = Math.round(b * 0.4 + 248 * 0.6);
        odata[p + 3] = 255;
      } else {
        // Dimmed background
        odata[p] = Math.round(r * 0.55);
        odata[p + 1] = Math.round(g * 0.55);
        odata[p + 2] = Math.round(b * 0.55);
        odata[p + 3] = 255;
      }
    }
  }

  octx.putImageData(overlayImg, 0, 0);

  // Compute Laplacian variance for focus/sharpness
  let lapSum = 0;
  let lapSqSum = 0;
  let lapCount = 0;
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const idx = y * width + x;
      if (isBackground[idx]) continue;
      const lap =
        gray[idx - 1] +
        gray[idx + 1] +
        gray[idx - width] +
        gray[idx + width] -
        4 * gray[idx];
      lapSum += lap;
      lapSqSum += lap * lap;
      lapCount++;
    }
  }

  const lapMean = lapCount > 10 ? lapSum / lapCount : 0;
  const lapVar = lapCount > 10 ? lapSqSum / lapCount - lapMean * lapMean : 0;
  const sharpnessScore = Math.min(100, Math.round(Math.sqrt(Math.max(0, lapVar)) * 2.4));

  const denom = Math.max(1, leafPixelCount);
  const vegetationCoveragePct = Math.round((leafPixelCount / totalPixels) * 1000) / 10;
  const organicGreenOrYellowPct = Math.round(((greenCount + chlorosisCount) / denom) * 1000) / 10;

  const healthyGreenPct = Math.round((greenCount / denom) * 1000) / 10;
  const chlorosisPct = Math.round((chlorosisCount / denom) * 1000) / 10;
  const necrosisPct = Math.round((necrosisCount / denom) * 1000) / 10;
  const rustOrangePct = Math.round((rustCount / denom) * 1000) / 10;
  const powderyWhitePct = Math.round((powderyCount / denom) * 1000) / 10;
  const edgeBrownPct = Math.round((edgeBrownCount / denom) * 1000) / 10;
  const avgBrightness = Math.round(brightnessSum / totalPixels);

  return {
    width: img.width,
    height: img.height,
    vegetationCoveragePct,
    organicGreenOrYellowPct,
    healthyGreenPct,
    chlorosisPct,
    necrosisPct,
    rustOrangePct,
    powderyWhitePct,
    edgeBrownPct,
    sharpnessScore,
    avgBrightness,
    overlayDataUrl: overlayCanvas.toDataURL('image/png'),
  };
}

export function runLocalDiagnosis(metrics, plantHint = 'auto', symptomsHint = []) {
  // Leaf verification gate
  const hasPlantTissue =
    metrics.vegetationCoveragePct >= 9 &&
    (metrics.healthyGreenPct + metrics.chlorosisPct >= 18 || metrics.rustOrangePct >= 10);

  if (!hasPlantTissue) {
    return {
      isLeaf: false,
      rejectionReason:
        'No clear plant leaf foliage was detected in this image (low chlorophyll / organic leaf coverage). Please upload or capture a close-up photo of a single plant leaf in natural daylight, or connect a Gemini Vision API key in Settings for general multimodal verification.',
      plantCommonName: 'Unrecognized Subject',
      plantScientificName: '—',
      diseaseName: 'No Leaf Detected',
      isHealthy: false,
      pathogenType: 'Non-Plant',
      severity: 'None',
      confidence: 0,
      summary:
        'Agri Guard paused diagnosis to prevent false disease guesses on a non-leaf or severely underexposed photo.',
      observedSymptoms: [
        `Detected leaf coverage: ${metrics.vegetationCoveragePct}%`,
        `Green + chlorotic leaf tissue: ${metrics.organicGreenOrYellowPct}%`,
      ],
      howToSolve: {
        immediateActions: [
          'Center one clear leaf against a plain light or neutral background.',
          'Tap to focus on the leaf surface and avoid harsh shadows or glare.',
        ],
        organicRemedies: [],
        targetedTreatments: [],
        recoveryTimeline: 'N/A',
      },
      healthyCareAdvice: {
        watering: 'Retake a crisp leaf photo to receive customized watering advice.',
        sunlightAndAirflow: 'Capture in bright, indirect outdoor daylight.',
        soilAndNutrition: 'Ensure both healthy and spotted areas of the leaf are visible.',
        preventiveChecklist: [],
      },
      accuracyNotes:
        'Leaf gate rejected this image so Agri Guard never fabricates a diagnosis when a leaf is absent.',
    };
  }

  const normalizedPlant = (plantHint || 'auto').toLowerCase();
  const symptomSet = new Set(symptomsHint || []);

  const scored = DISEASE_DATABASE.map((entry) => {
    const sig = entry.signature;
    let score = 0;

    // 1. Optical pixel signature matching (60 pts max)
    const greenScore = rangeFitScore(metrics.healthyGreenPct, sig.idealGreen);
    const chloroScore = rangeFitScore(metrics.chlorosisPct, sig.idealChlorosis);
    const necroScore = rangeFitScore(metrics.necrosisPct, sig.idealNecrosis);
    const rustScore = rangeFitScore(metrics.rustOrangePct, sig.idealRust);
    const powderScore = rangeFitScore(metrics.powderyWhitePct, sig.idealPowdery);
    const edgeScore = rangeFitScore(metrics.edgeBrownPct, sig.idealEdgeBrown);

    score +=
      greenScore * 14 +
      chloroScore * 12 +
      necroScore * 14 +
      rustScore * 10 +
      powderScore * 10 +
      edgeScore * 8;

    // Hard boosts / penalties for strong specific pathology signals
    if (sig.healthyOnly) {
      if (
        metrics.healthyGreenPct >= 68 &&
        metrics.necrosisPct < 3.5 &&
        metrics.chlorosisPct < 8 &&
        metrics.powderyWhitePct < 4 &&
        metrics.rustOrangePct < 2.5
      ) {
        score += 24;
      } else {
        score -= 22;
      }
    }

    if (sig.powderyMin && metrics.powderyWhitePct >= sig.powderyMin) score += 20;
    if (sig.rustMin && metrics.rustOrangePct >= sig.rustMin) score += 20;
    if (sig.chlorosisMin && metrics.chlorosisPct >= sig.chlorosisMin && metrics.necrosisPct <= (sig.necrosisMax ?? 100)) {
      score += 18;
    }
    if (sig.edgeBrownMin && metrics.edgeBrownPct >= sig.edgeBrownMin && metrics.necrosisPct < 25) {
      score += 16;
    }

    // 2. Plant species alignment (26 pts max)
    if (normalizedPlant !== 'auto') {
      const entryPlant = entry.plantCommonName.toLowerCase();
      if (entryPlant.includes(normalizedPlant)) {
        score += 28;
      } else if (
        entry.id === 'healthy-leaf' ||
        entry.id === 'powdery-mildew-general' ||
        entry.id === 'nutrient-chlorosis-iron-nitrogen' ||
        entry.id === 'abiotic-leaf-scorch' ||
        entry.id === 'viral-mosaic-curl'
      ) {
        score += 8; // Broad-host conditions remain valid possibilities
      } else {
        score -= 24; // Avoid matching e.g. Rice Brown Spot when user picked Apple
      }
    }

    // 3. User-observed symptom tags (18 pts max)
    if (symptomSet.size > 0 && Array.isArray(sig.symptomTags)) {
      let matches = 0;
      for (const tag of sig.symptomTags) {
        if (symptomSet.has(tag)) matches++;
      }
      score += matches * 12;
    }

    return { entry, score };
  });

  scored.sort((a, b) => b.score - a.score);
  const top = scored[0];
  const runnerUp = scored[1];

  // Resolve plant name cleanly if user specified one for a broad-host condition
  const selectedPlantObj = PLANT_SPECIES_OPTIONS.find(
    (p) => p.value.toLowerCase() === normalizedPlant
  );
  const resolvedPlantName =
    normalizedPlant !== 'auto' && selectedPlantObj
      ? selectedPlantObj.label.split(' (')[0]
      : top.entry.plantCommonName;

  // Calibrate honest confidence (max 94% in offline pixel-screening mode)
  const margin = Math.max(0, top.score - (runnerUp?.score ?? 0));
  const rawConf = Math.round(52 + Math.min(28, margin * 1.1) + (normalizedPlant !== 'auto' ? 8 : 0) + (metrics.sharpnessScore > 30 ? 4 : -4));
  const confidence = Math.max(48, Math.min(93, rawConf));

  const dynamicObservations = [
    ...top.entry.observedSymptoms,
    `Optical scan measured ${metrics.healthyGreenPct}% healthy green, ${metrics.chlorosisPct}% yellowing, ${metrics.necrosisPct}% dark spots, ${metrics.rustOrangePct}% rust-orange, and ${metrics.powderyWhitePct}% white surface coating.`,
  ];

  const accuracyNotes =
    normalizedPlant === 'auto'
      ? `Local Pixel & Symptom Screening mode (${confidence}% confidence). Closest differential: ${runnerUp?.entry.diseaseName || 'None'}. For species-level precision above 95% on arbitrary photos, select your plant species above or enable Gemini Vision AI in API Settings.`
      : `Local Pixel & Symptom Screening mode (${confidence}% confidence) calibrated for ${resolvedPlantName}. Closest differential: ${runnerUp?.entry.diseaseName || 'None'}.`;

  return {
    isLeaf: true,
    rejectionReason: null,
    plantCommonName: resolvedPlantName,
    plantScientificName:
      normalizedPlant !== 'auto' && selectedPlantObj?.label.includes('(')
        ? selectedPlantObj.label.match(/\(([^)]+)\)/)?.[1] || top.entry.plantScientificName
        : top.entry.plantScientificName,
    diseaseName: top.entry.diseaseName,
    isHealthy: top.entry.isHealthy,
    pathogenType: top.entry.pathogenType,
    severity: top.entry.severity,
    confidence,
    summary: top.entry.summary,
    observedSymptoms: dynamicObservations,
    howToSolve: top.entry.howToSolve,
    healthyCareAdvice: top.entry.healthyCareAdvice,
    accuracyNotes,
    alternatives: scored.slice(1, 3).map((item) => ({
      diseaseName: item.entry.diseaseName,
      plantCommonName: item.entry.plantCommonName,
      pathogenType: item.entry.pathogenType,
    })),
  };
}
