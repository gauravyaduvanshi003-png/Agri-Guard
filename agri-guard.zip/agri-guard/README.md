# Agri Guard — Plant Leaf Disease Detection & Care System

Agri Guard is a full-stack web application where anyone can capture or upload a photo of a plant leaf to identify the **plant/leaf name**, detect the **disease**, inspect a **pixel-level lesion heatmap**, get **step-by-step organic and targeted treatments**, and follow **healthy plant care advice**.

## Features

- **Live Camera & Photo Upload**: Snap directly from desktop/mobile camera or drag-and-drop leaf images, plus 4 instant demo leaf specimens.
- **Two-Tier Diagnosis Engine**:
  1. **Gemini Vision AI Mode** (optional API key in `.env` or in-app API Settings): Multimodal plant pathology diagnosis across thousands of species with calibrated confidence.
  2. **Local Optical Screening Mode** (built-in, works offline): Segments leaf tissue from the background, measures healthy green, chlorosis (yellowing), necrosis (dark lesions), rust pustules, powdery mildew, and focus sharpness, and generates an interactive **Lesion Heatmap** overlay.
- **Leaf Verification Gate**: Rejects non-leaf or severely blurry photos rather than fabricating a diagnosis.
- **Disease Guide & History**: Searchable encyclopedia of common plant diseases and local scan history with printable PDF reports.

## Accuracy Note

No real-world computer vision system can guarantee 100% accuracy on arbitrary photos because lighting, focus, overlapping nutrient deficiencies, and look-alike pathogens vary widely. Agri Guard maximizes real-world accuracy through:
1. Optical quality & leaf-presence checks before diagnosis
2. Optional species & symptom refinement
3. Gemini Vision multimodal analysis with calibrated confidence & differential notes

## Running Locally

```bash
npm install
npm run dev
```

- Frontend: `http://localhost:5173`
- Backend API proxy: `http://localhost:3001`

To enable Gemini Vision AI on the server, copy `.env.example` to `.env` and set `GEMINI_API_KEY=your_key_here` (or paste your key inside the app's **API Settings** button).
