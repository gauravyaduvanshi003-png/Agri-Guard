import { spawn } from 'node:child_process';
import path from 'node:path';

const viteCli = path.resolve('node_modules', 'vite', 'bin', 'vite.js');

function start(name, cmd, args) {
  const proc = spawn(cmd, args, {
    stdio: 'inherit',
  });
  proc.on('exit', (code) => {
    if (code && code !== 0) {
      console.error(`[${name}] exited with code ${code}`);
    }
  });
  return proc;
}

const server = start('server', process.execPath, ['server/index.js']);
const client = start('client', process.execPath, [viteCli]);

function shutdown() {
  server.kill();
  client.kill();
  process.exit(0);
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
